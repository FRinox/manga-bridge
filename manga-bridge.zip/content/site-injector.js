// ==========================================
// Manga-Bridge Universal — content script principal
// S'exécute sur tous les sites (sauf mangacollec.com, géré séparément).
// ==========================================
(function () {
  'use strict';

  const HOSTNAME = location.hostname;
  let selectorSets = [];    // [{ cardSelector, titleSelector, label }, ...]
  let confirmed = {};
  let aliases = {};
  let settings = null;
  // ========================================
  // État global du mode apprentissage
  // ========================================
  let learning = null;      // null ou { step, cardEl, cardSelector }
  let learnHighlightWatchdog = null;

  function computeBubbleStyle() {
    const gap = 14;
    const panelPos = settings?.panelPosition || 'bottom-right';
    const [vert, horiz] = panelPos.split('-');
    const style = { position: 'fixed', flexDirection: (horiz === 'left') ? 'row' : 'row-reverse' };

    const panel = document.getElementById('mb-control-panel');
    if (panel) {
      // Même côté horizontal que le panneau, mais empilée à côté de lui
      // (au-dessus s'il est en bas, en-dessous s'il est en haut) plutôt
      // qu'en diagonale opposée — reste proche des boutons sans jamais les
      // recouvrir.
      const rect = panel.getBoundingClientRect();
      if (vert === 'bottom') {
        style.bottom = Math.max(gap, window.innerHeight - rect.top + gap) + 'px';
        style.top = 'auto';
      } else {
        style.top = (rect.bottom + gap) + 'px';
        style.bottom = 'auto';
      }
      if (horiz === 'right') {
        style.right = Math.max(gap, window.innerWidth - rect.right) + 'px';
        style.left = 'auto';
      } else {
        style.left = rect.left + 'px';
        style.right = 'auto';
      }
    } else {
      // Panneau pas encore affiché (site pas activé) : coin classique par défaut.
      style.top = vert === 'top' ? '24px' : 'auto';
      style.bottom = vert === 'bottom' ? '24px' : 'auto';
      style.left = horiz === 'left' ? '24px' : 'auto';
      style.right = horiz === 'right' ? '24px' : 'auto';
    }
    return style;
  }

  // Positionne le panneau À CÔTÉ de l'élément sélectionné (gauche ou droite)
  // pour qu'il ne le recouvre jamais. Alignement vertical centré sur l'élément.
  // Utilise position:fixed pour rester ancrée au viewport malgré le scroll.
  function positionBubbleAbove(el) {
    const rect = el.getBoundingClientRect();
    const gap = 14;
    const panelWidth = 420;
    const panelHeight = 180; // hauteur estimée du panneau

    // Décide si on place à droite ou à gauche selon l'espace disponible
    const spaceRight = window.innerWidth - (rect.right + gap);
    const spaceLeft = rect.left - gap;
    const placeOnRight = spaceRight >= panelWidth || spaceRight > spaceLeft;

    // Position horizontale : à droite ou à gauche de l'élément
    let leftPx;
    let rightPx;
    let mascotSide;
    if (placeOnRight) {
      leftPx = rect.right + gap;
      rightPx = 'auto';
      mascotSide = 'right'; // mascotte du côté droit (bord écran)
    } else {
      leftPx = rect.left - panelWidth - gap;
      rightPx = 'auto';
      mascotSide = 'left'; // mascotte du côté gauche (bord écran)
    }
    // Garder le panneau dans le viewport horizontalement
    leftPx = Math.max(8, Math.min(leftPx, window.innerWidth - panelWidth - 8));

    // Position verticale : centrée sur l'élément, clampée dans le viewport
    let topPx = rect.top + (rect.height - panelHeight) / 2;
    topPx = Math.max(8, Math.min(topPx, window.innerHeight - panelHeight - 8));

    return {
      position: 'fixed',
      top: topPx + 'px',
      bottom: 'auto',
      left: leftPx + 'px',
      right: 'auto',
      flexDirection: mascotSide === 'left' ? 'row-reverse' : 'row',
      mascotSide
    };
  }

  // Positions statiques alternatives au mode "suivi" : bas-droite ou
  // bas-gauche uniquement. Mascotte + bulle restent TOUJOURS un seul bloc
  // côte à côte (la mascotte au bord de l'écran semble "pointer" vers la
  // bulle qui s'étend vers le centre). Si le panneau de contrôle est
  // exactement au même coin, on s'empile strictement au-dessus de lui —
  // jamais de chevauchement.
  function computeStaticBubbleStyle(mode) {
    const gap = 14;
    const panel = document.getElementById('mb-control-panel');
    const panelRect = panel ? panel.getBoundingClientRect() : null;
    const panelPos = settings?.panelPosition || 'bottom-right';
    const horiz = mode === 'bottom-left' ? 'left' : 'right';

    const style = {
      position: 'fixed',
      top: 'auto',
      // Le DOM est toujours [contenu, mascotte] (même convention que la
      // bulle simple). Un bloc ancré via `right` doit avoir la mascotte en
      // DERNIER visuellement (donc 'row', pas 'row-reverse') pour qu'elle
      // touche le vrai bord droit de l'écran ; ancré via `left`, c'est
      // l'inverse ('row-reverse' place la mascotte en premier, au bord
      // gauche).
      flexDirection: horiz === 'left' ? 'row-reverse' : 'row'
    };
    style.left = horiz === 'left' ? gap + 'px' : 'auto';
    style.right = horiz === 'right' ? gap + 'px' : 'auto';

    if (panelRect && panelPos === mode) {
      style.bottom = Math.max(gap, window.innerHeight - panelRect.top + gap) + 'px';
      if (horiz === 'left') style.left = panelRect.left + 'px';
      else style.right = Math.max(gap, window.innerWidth - panelRect.right) + 'px';
    } else {
      style.bottom = gap + 'px';
    }
    return style;
  }

  // Affiche l'instruction de l'étape en cours. En mode "follow" (défaut),
  // se positionne au-dessus de l'élément concerné (case sélectionnée,
  // élément survolé...) ; sinon respecte la position statique choisie dans
  // les options (bas/droite/gauche). Mémorise le message pour pouvoir
  // re-positionner la bulle sans le perdre.
  function showLearnBubble(text, anchorEl, autoHideMs) {
    if (learning) learning.message = text;
    const style = computeLearnUIStyle(anchorEl);
    window.MangaBridgeMascot.showBubble(text, { style, autoHideMs });
  }

  // Calcul de position PARTAGÉ entre la bulle mascotte seule et le panneau
  // de candidats — les deux utilisent exactement la même logique, donc ils
  // apparaissent toujours au même endroit (jamais l'un figé et l'autre non).
  function computeLearnUIStyle(anchorEl) {
    const mode = settings?.bubbleMode || 'follow';
    if (mode === 'follow') {
      return anchorEl ? positionBubbleAbove(anchorEl) : computeBubbleStyle();
    }
    return computeStaticBubbleStyle(mode);
  }

  // ==========================================
  // GÉNÉRATION DE CANDIDATS DE SÉLECTEURS
  // ==========================================
  // Tags "nus" (sans classe) jugés trop génériques pour être proposés tels
  // quels — sauf ceux réputés porter le contenu utile (lien, titre).
  const MB_GENERIC_BARE_TAGS = new Set(['div', 'span', 'p', 'b', 'i', 'u', 'br', 'center', 'form', 'tr', 'td', 'ul', 'li', 'img', 'button', 'input', 'strong', 'small']);
  const MB_SEMANTIC_TAGS = new Set(['a', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6']);

  function isTooGenericSelector(selector, count, maxCount) {
    if (count > maxCount) return true;
    const isBareTag = /^[a-z][a-z0-9]*$/i.test(selector);
    if (isBareTag && MB_GENERIC_BARE_TAGS.has(selector.toLowerCase())) return true;
    return false;
  }

  function computeCandidates(rawList, root, maxCount) {
    const seen = new Set();
    const out = [];
    rawList.forEach(({ label, selector, priority }) => {
      if (!selector || seen.has(selector)) return;
      seen.add(selector);
      let count = 0;
      try { count = root.querySelectorAll(selector).length; } catch (e) { /* sélecteur invalide */ }
      if (count > 0 && !isTooGenericSelector(selector, count, maxCount)) {
        out.push({ label, selector, count, priority: priority || 0 });
      }
    });
    out.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      const score = c => (c.count >= 2 && c.count <= 400) ? 1000 - c.count : -c.count;
      return score(b) - score(a);
    });
    return out;
  }

  // Filtre les classes internes de l'extension (mb-*) pour ne pas les proposer
  // comme sélecteurs candidats.
  function isMBClass(className) {
    return /^mb-/.test(className);
  }

  function generateCardCandidates(el) {
    const raw = [];
    if (el.id) raw.push({ label: '#' + el.id, selector: '#' + CSS.escape(el.id) });
    // Exclure les classes internes de l'extension
    Array.from(el.classList).forEach(c => {
      if (!isMBClass(c)) raw.push({ label: '.' + c, selector: '.' + CSS.escape(c) });
    });
    const tag = el.tagName.toLowerCase();
    raw.push({ label: tag, selector: tag });
    if (el.classList.length) {
      const filtered = Array.from(el.classList).filter(c => !isMBClass(c));
      const full = tag + '.' + filtered.map(c => CSS.escape(c)).join('.');
      raw.push({ label: full, selector: full });
    }
    if (el.parentElement) {
      Array.from(el.parentElement.classList).forEach(c => {
        if (!isMBClass(c)) {
          const sel = `.${CSS.escape(c)} > ${tag}`;
          raw.push({ label: sel, selector: sel });
        }
      });
    }
    return computeCandidates(raw, document, 1000);
  }

  function generateTitleCandidates(container, el) {
    const options = [{ label: '🔲 La case entière (pas de titre séparé)', selector: null, count: null, isSelf: true }];

    const raw = [];
    const addForNode = (node) => {
      const tag = node.tagName.toLowerCase();
      const priority = (tag === 'a') ? 0 : (MB_SEMANTIC_TAGS.has(tag) ? 1 : 2);
      // Exclure les classes internes de l'extension
      Array.from(node.classList).forEach(c => {
        if (!isMBClass(c)) raw.push({ label: '.' + c, selector: '.' + CSS.escape(c), priority });
      });
      raw.push({ label: tag, selector: tag, priority: priority + (MB_SEMANTIC_TAGS.has(tag) ? 0 : 1) });
    };

    // Le clic de l'utilisateur donne des candidats...
    if (el !== container) addForNode(el);
    // ...mais on propose AUSSI directement tous les liens/titres du conteneur :
    // c'est presque toujours la balise <a> qui porte le texte propre (titre +
    // tome) sans le bruit du prix/bouton, et l'utilisateur n'a pas toujours
    // cliqué dessus précisément au premier essai.
    container.querySelectorAll('a, h1, h2, h3, h4, h5, h6').forEach(node => addForNode(node));

    const scoped = computeCandidates(raw, container, container.querySelectorAll('*').length + 1);
    scoped.sort((a, b) => (a.priority !== b.priority) ? a.priority - b.priority : a.count - b.count);
    return options.concat(scoped);
  }

  // ==========================================
  // MODULE D'APPRENTISSAGE (réécrit)
  // ==========================================
  // Flux linéaire à 2 étapes, sans callbacks imbriqués :
  //   Étape 1 — Sélection de la case manga (cardSelector)
  //   Étape 2 — Sélection du titre dans la case (titleSelector)
  //   Finalisation — Sauvegarde + proposition d'ajouter un autre set
  //
  // Le nettoyage est centralisé dans cleanupLearning() pour éviter la
  // duplication et les fuites d'écouteurs d'événements.
  // L'état est géré par l'objet `learning` avec un champ `step` qui
  // contrôle le flux : 'card' → 'title' → null.

  // --- Aperçu live (pointillés bleus) ---
  function clearPreviewHighlight() {
    document.querySelectorAll('.mb-preview-highlight').forEach(el => el.classList.remove('mb-preview-highlight'));
  }

  function previewSelector(selector, root) {
    clearPreviewHighlight();
    if (!selector) return;
    try { (root || document).querySelectorAll(selector).forEach(el => el.classList.add('mb-preview-highlight')); }
    catch (e) { /* sélecteur invalide */ }
  }

  // --- Nettoyage centralisé ---
  // Unique point de sortie : retire tous les écouteurs, arrête le watchdog,
  // supprime les surbrillances et le panneau, et réinitialise l'état.
  // learning = null en premier pour tuer le watchdog immédiatement.
  function cleanupLearning() {
    // 1. Tuer l'état immédiatement → watchdog s'arrête de lui-même
    learning = null;

    // 2. Arrêter le watchdog
    clearInterval(learnHighlightWatchdog);
    learnHighlightWatchdog = null;

    // 3. Retirer les écouteurs
    document.removeEventListener('mouseover', handleLearnHover, true);
    document.removeEventListener('click', handleLearnClick, true);
    document.removeEventListener('keydown', handleLearnKeydown, true);
    document.body.style.cursor = '';

    // 4. Nettoyer les surbrillances
    clearPreviewHighlight();
    document.querySelectorAll('[data-mb-highlight]').forEach(el => {
      delete el.dataset.mbHighlight;
    });
    document.querySelectorAll('.mb-learn-card-context, .mb-learn-card-step2').forEach(el => {
      el.classList.remove('mb-learn-card-context', 'mb-learn-card-step2');
    });

    // 5. Retirer le panneau et la bulle
    document.getElementById('mb-learn-panel')?.remove();
    window.MangaBridgeMascot.hideBubble();
  }

  // --- Surbrillance orange persistante de la case ---
  // En étape 1 : contour simple. En étape 2 : contour double.
  // Le watchdog appelle cette fonction toutes les 500ms pour rester robuste
  // face aux re-renders SPA.
  // Stratégie : on garde cardEl comme source de vérité.
  // Si cardEl est toujours dans le DOM → on le réutilise.
  // Si cardEl a été détaché (re-render SPA) → on recherche via le sélecteur.
  function refreshCardHighlight() {
    if (!learning) return;

    let target = null;

    // 1. cardEl est toujours dans le DOM ? → on le garde
    if (learning.cardEl && document.body.contains(learning.cardEl)) {
      target = learning.cardEl;
    }

    // 2. cardEl détaché → on cherche via le sélecteur
    if (!target && learning.cardSelector) {
      try { target = document.querySelector(learning.cardSelector); } catch (e) { /* ignore */ }
    }

    if (target) {
      // Nettoyer les anciennes surbrillances et réappliquer
      document.querySelectorAll('.mb-learn-card-context, .mb-learn-card-step2').forEach(el => {
        el.classList.remove('mb-learn-card-context', 'mb-learn-card-step2');
      });
      target.classList.add('mb-learn-card-context');
      if (learning.step === 'title') {
        target.classList.add('mb-learn-card-step2');
      }
      learning.cardEl = target;
    }
    // Sinon : on ne fait rien, la surbrillance existante reste en place
  }

  // --- Rendu du panneau de candidats ---
  // Affiche une liste de sélecteurs avec prévisualisation au survol.
  // Le panneau se positionne à côté de l'élément d'ancrage (never overlaps).
  function renderCandidatePanel(title, instructions, candidates, previewRoot, onSelect, anchorEl) {
    window.MangaBridgeMascot.hideBubble();

    let panel = document.getElementById('mb-learn-panel');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'mb-learn-panel';
      document.body.appendChild(panel);
    }

    const style = computeLearnUIStyle(anchorEl);
    panel.style.position = style.position || 'fixed';
    panel.style.top = style.top ?? 'auto';
    panel.style.bottom = style.bottom ?? 'auto';
    panel.style.left = style.left ?? 'auto';
    panel.style.right = style.right ?? 'auto';
    panel.dataset.mascotSide = style.mascotSide || ((style.flexDirection === 'row-reverse') ? 'left' : 'right');

    // Construction DOM sécurisée (pas d'innerHTML)
    panel.innerHTML = '';
    const contentDiv = document.createElement('div');
    contentDiv.className = 'mb-learn-content';
    const h3 = document.createElement('h3');
    h3.textContent = title;
    contentDiv.appendChild(h3);
    const p = document.createElement('p');
    p.textContent = instructions;
    contentDiv.appendChild(p);
    const listContainer = document.createElement('div');
    listContainer.className = 'mb-candidate-list';
    contentDiv.appendChild(listContainer);
    const actionsContainer = document.createElement('div');
    actionsContainer.className = 'mb-actions';
    contentDiv.appendChild(actionsContainer);
    panel.appendChild(contentDiv);
    const mascotDiv = document.createElement('div');
    mascotDiv.className = 'mb-learn-mascot';
    mascotDiv.innerHTML = window.MangaBridgeMascot.svg(40); // SVG interne, pas de donnée utilisateur
    panel.appendChild(mascotDiv);

    const list = panel.querySelector('.mb-candidate-list');
    if (candidates.length === 0) {
      const empty = document.createElement('p');
      empty.style.cssText = 'color:#8a8a95; font-size:11.5px; font-style:italic;';
      empty.innerText = "Aucun sélecteur exploitable trouvé — essaie un autre élément.";
      list.appendChild(empty);
    } else {
      candidates.forEach(c => {
        const row = document.createElement('div');
        row.className = 'mb-candidate';
        const codeEl = document.createElement('code');
        codeEl.textContent = c.label;
        row.appendChild(codeEl);
        const countSpan = document.createElement('span');
        countSpan.className = 'mb-count';
        countSpan.textContent = c.isSelf ? '' : `${c.count} élément(s)`;
        row.appendChild(countSpan);
        row.onmouseenter = () => previewSelector(c.selector, previewRoot);
        row.onmouseleave = () => clearPreviewHighlight();
        row.onclick = () => { clearPreviewHighlight(); onSelect(c); };
        list.appendChild(row);
      });
    }

    const actions = panel.querySelector('.mb-actions');
    const cancelBtn = document.createElement('button');
    cancelBtn.innerText = '❌ Annuler';
    cancelBtn.style.background = '#34495e';
    cancelBtn.onclick = cleanupLearning;
    actions.appendChild(cancelBtn);
  }

  // --- Gestionnaire de survol ---
  function handleLearnHover(e) {
    if (!learning) return;
    if (e.target.closest('#mb-learn-panel') || e.target.closest('#mb-mascot-bubble')) return;
    document.querySelectorAll('[data-mb-highlight]').forEach(el => {
      if (el.classList.contains('mb-learn-card-context')) return;
      delete el.dataset.mbHighlight;
    });
    e.target.dataset.mbHighlight = 'true';
  }

  // --- Gestionnaire de touches (Escape) ---
  function handleLearnKeydown(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      cleanupLearning();
    }
  }

  // --- Gestionnaire de clic unique (point d'entrée) ---
  // Délégué vers la bonne fonction selon learning.step.
  async function handleLearnClick(e) {
    if (!learning) return;
    if (e.target.closest('#mb-learn-panel') || e.target.closest('#mb-mascot-bubble')) return;
    e.preventDefault();
    e.stopPropagation();

    if (learning.step === 'card') {
      await onCardClick(e.target);
    } else if (learning.step === 'title') {
      await onTitleClick(e.target);
    }
  }

  // --- ÉTAPE 1 : Clic sur un élément → proposition de cardSelector ---
  async function onCardClick(el) {
    // Surbrillance orange immédiate sur l'élément cliqué
    learning.cardEl = el;
    el.classList.add('mb-learn-card-context');

    const candidates = generateCardCandidates(el);
    renderCandidatePanel(
      'Étape 1/2 — La case du manga',
      "Choisis le sélecteur qui correspond au cadre complet du manga (survol = prévisualisation).",
      candidates,
      document,
      (candidate) => {
        // Résoudre l'élément réel via closest() pour s'assurer qu'on a bien la case entière
        const resolvedCard = (candidate.selector && el.closest(candidate.selector)) || el;
        learning.cardEl = resolvedCard;
        learning.cardSelector = candidate.selector;

        // Surbrillance orange persistante
        refreshCardHighlight();

        // Passage à l'étape 2
        learning.step = 'title';
        showTitleSelection(resolvedCard);
      },
      el
    );
  }

  // --- ÉTAPE 2 : Afficher le panneau de sélection du titre ---
  function showTitleSelection(card) {
    const candidates = generateTitleCandidates(card, card);
    renderCandidatePanel(
      'Étape 2/2 — Le titre du manga',
      "Choisis le sélecteur du titre (survol = prévisualisation), ou clique directement sur l'élément titre dans la case orange.",
      candidates,
      card,
      (candidate) => {
        onTitleCandidateSelected(card, candidate);
      },
      card
    );
  }

  // --- ÉTAPE 2 : Clic manuel sur un élément dans la case ---
  async function onTitleClick(el) {
    // Trouver la case qui contient l'élément cliqué via closest()
    // (querySelector retourne la 1ère occurrence, pas celle qu'on veut)
    let card = null;
    if (learning.cardSelector) {
      try { card = el.closest(learning.cardSelector); } catch (e) { /* ignore */ }
    }
    // Fallback : cardEl s'il est toujours dans le DOM
    if (!card && learning.cardEl && document.body.contains(learning.cardEl)) {
      card = learning.cardEl;
    }
    // Si rien ne marche, on arrête
    if (!card) return;

    // Vérifier que le clic est bien dans la case
    if (!card.contains(el)) {
      const warnMode = settings?.bubbleMode || 'follow';
      window.MangaBridgeMascot.showBubble("Clique À L'INTÉRIEUR de la case orange !", {
        autoHideMs: 2000,
        style: warnMode === 'follow' ? positionBubbleAbove(card) : computeStaticBubbleStyle(warnMode)
      });
      return;
    }
    // Régénérer les candidats avec le nouvel élément cliqué
    const candidates = generateTitleCandidates(card, el);
    renderCandidatePanel(
      'Étape 2/2 — Le titre du manga',
      "Choisis le sélecteur du titre (survol = prévisualisation), ou reclique sur un autre élément de la case.",
      candidates,
      card,
      (candidate) => {
        onTitleCandidateSelected(card, candidate);
      },
      card
    );
  }

  // --- ÉTAPE 2 : Candidat de titre sélectionné → vérification concat ---
  function onTitleCandidateSelected(card, candidate) {
    const titleSelector = candidate.selector; // peut être null si "case entière"

    // Compter les occurrences dans la case
    let matchCount = 0;
    if (titleSelector) {
      try { matchCount = card.querySelectorAll(titleSelector).length; } catch (e) { /* ignore */ }
    }

    if (!titleSelector || matchCount <= 1) {
      // Pas d'ambiguïté → finalisation directe
      finalizeSet(learning.cardSelector, titleSelector, false);
      return;
    }

    // Plusieurs occurrences → on pose la question
    showConcatQuestion(card, titleSelector, matchCount);
  }

  // --- Question de regroupement (concat) ---
  function showConcatQuestion(card, titleSelector, matchCount) {
    window.MangaBridgeMascot.hideBubble();

    let panel = document.getElementById('mb-learn-panel');
    if (!panel) { panel = document.createElement('div'); panel.id = 'mb-learn-panel'; document.body.appendChild(panel); }

    const style = computeLearnUIStyle(card);
    panel.style.position = style.position || 'fixed';
    panel.style.top = style.top ?? 'auto';
    panel.style.bottom = style.bottom ?? 'auto';
    panel.style.left = style.left ?? 'auto';
    panel.style.right = style.right ?? 'auto';
    panel.dataset.mascotSide = style.mascotSide || ((style.flexDirection === 'row-reverse') ? 'left' : 'right');

    panel.innerHTML = `
      <div class="mb-learn-content">
        <h3>Une précision...</h3>
        <p>Ce sélecteur correspond à ${matchCount} éléments dans cette case (ex: nom de série + numéro de tome séparés). Faut-il les regrouper TOUS pour former le titre complet ?</p>
        <div class="mb-actions"></div>
      </div>
      <div class="mb-learn-mascot">${window.MangaBridgeMascot.svg(40)}</div>
    `;

    const actions = panel.querySelector('.mb-actions');
    const yesBtn = document.createElement('button');
    yesBtn.innerText = '✅ Oui, les regrouper';
    yesBtn.style.background = '#27ae60';
    yesBtn.onclick = () => finalizeSet(learning.cardSelector, titleSelector, true);

    const noBtn = document.createElement('button');
    noBtn.innerText = '➡️ Non, garder le 1er seulement';
    noBtn.style.background = '#7f8c8d';
    noBtn.onclick = () => finalizeSet(learning.cardSelector, titleSelector, false);

    actions.appendChild(yesBtn);
    actions.appendChild(noBtn);
  }

  // --- Finalisation : sauvegarde + proposition d'ajouter un autre set ---
  async function finalizeSet(cardSelector, titleSelector, titleConcat) {
    // Tuer le watchdog et les écouteurs MAINTENANT (avant les await async)
    // pour qu'il ne se passe plus rien pendant la sauvegarde.
    clearInterval(learnHighlightWatchdog);
    learnHighlightWatchdog = null;
    document.removeEventListener('mouseover', handleLearnHover, true);
    document.removeEventListener('click', handleLearnClick, true);
    document.removeEventListener('keydown', handleLearnKeydown, true);
    document.body.style.cursor = '';

    // Nettoyer les surbrillances immédiatement (avant les await)
    clearPreviewHighlight();
    document.querySelectorAll('[data-mb-highlight]').forEach(el => {
      delete el.dataset.mbHighlight;
    });
    document.querySelectorAll('.mb-learn-card-context, .mb-learn-card-step2').forEach(el => {
      el.classList.remove('mb-learn-card-context', 'mb-learn-card-step2');
    });

    // Sauvegarde
    await window.MangaBridgeStorage.addSelectorSet(HOSTNAME, {
      cardSelector,
      titleSelector,
      titleConcat: !!titleConcat,
      label: await nextSetLabel(HOSTNAME)
    });

    // Nettoyage complet (learning = null + nettoyage DOM)
    cleanupLearning();

    // Panneau de fin
    showFinalPanel();
  }

  // --- Panneau de fin : ajouter un autre set ou terminer ---
  function showFinalPanel() {
    window.MangaBridgeMascot.hideBubble();

    let panel = document.getElementById('mb-learn-panel');
    if (!panel) { panel = document.createElement('div'); panel.id = 'mb-learn-panel'; document.body.appendChild(panel); }

    const style = computeLearnUIStyle(null);
    panel.style.position = style.position || 'fixed';
    panel.style.top = style.top ?? 'auto';
    panel.style.bottom = style.bottom ?? 'auto';
    panel.style.left = style.left ?? 'auto';
    panel.style.right = style.right ?? 'auto';
    panel.dataset.mascotSide = style.mascotSide || ((style.flexDirection === 'row-reverse') ? 'left' : 'right');

    panel.innerHTML = `
      <div class="mb-learn-content">
        <h3>🎉 Sélecteur ajouté !</h3>
        <p>Ce site a-t-il un AUTRE type de case manga (ex: liste vs grille, section promo...) à ajouter aussi ?</p>
        <div class="mb-actions"></div>
      </div>
      <div class="mb-learn-mascot">${window.MangaBridgeMascot.svg(40)}</div>
    `;

    const actions = panel.querySelector('.mb-actions');

    const yesBtn = document.createElement('button');
    yesBtn.innerText = '➕ Oui, ajouter un autre';
    yesBtn.style.background = '#f16522';
    yesBtn.onclick = () => {
      document.getElementById('mb-learn-panel')?.remove();
      startLearningMode();
    };

    const doneBtn = document.createElement('button');
    doneBtn.innerText = '✅ Terminé';
    doneBtn.style.background = '#27ae60';
    doneBtn.onclick = async () => {
      document.getElementById('mb-learn-panel')?.remove();
      window.MangaBridgeMascot.hideBubble();
      selectorSets = await window.MangaBridgeStorage.getSelectorSets(HOSTNAME);
      refreshControlPanelMode();
      resetProcessedCards();
      processAllPendingCards();
    };

    actions.appendChild(yesBtn);
    actions.appendChild(doneBtn);
  }

  // --- Génération du label du set ---
  async function nextSetLabel(hostname) {
    const sets = await window.MangaBridgeStorage.getSelectorSets(hostname);
    let maxN = 0;
    sets.forEach(s => {
      const m = /^Set (\d+)$/.exec(s.label || '');
      if (m) maxN = Math.max(maxN, parseInt(m[1], 10));
    });
    return `Set ${maxN + 1}`;
  }

  // --- Démarrage du mode apprentissage ---
  function startLearningMode() {
    if (!siteEnabled) {
      siteEnabled = true;
      window.MangaBridgeStorage.setSiteEnabled(HOSTNAME, true);
      injectControlPanel();
    }

    // Nettoyer tout état précédent (au cas où)
    if (learning) cleanupLearning();

    // Initialisation de l'état
    learning = { step: 'card' };
    document.body.style.cursor = 'crosshair';

    // Écouteurs
    document.addEventListener('mouseover', handleLearnHover, true);
    document.addEventListener('click', handleLearnClick, true);
    document.addEventListener('keydown', handleLearnKeydown, true);

    // Instruction
    showLearnBubble("Clique sur la CASE (le cadre complet) d'un manga sur cette page !", null);

    // Watchdog : maintient la surbrillance orange malgré les re-renders SPA
    clearInterval(learnHighlightWatchdog);
    learnHighlightWatchdog = setInterval(refreshCardHighlight, 500);
  }

  // --- Listener de messages (background ↔ content) ---
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === 'MB_START_LEARNING') {
      startLearningMode();
      sendResponse({ ok: true });
      return false;
    }
    if (msg?.type === 'MB_HAS_PROFILE') {
      sendResponse({ hasProfile: selectorSets.length > 0, hostname: HOSTNAME });
      return false;
    }
    return false;
  });

  // ==========================================
  // PANNEAU DE CONTRÔLE
  // ==========================================
  function refreshControlPanelMode() {
    document.getElementById('mb-control-panel')?.remove();
    injectControlPanel();
  }

  function refreshFilterButtonLabel(btnEl) {
    const btn = btnEl || document.getElementById('mb-filter-btn');
    if (btn) btn.innerText = settings?.hideOwned ? '👁️ Afficher' : '🙈 Masquer';
  }

  function applyPanelPosition() {
    const panel = document.getElementById('mb-control-panel');
    if (!panel) return;
    panel.classList.remove('mb-pos-top-right', 'mb-pos-top-left', 'mb-pos-bottom-right', 'mb-pos-bottom-left');
    panel.classList.add('mb-pos-' + (settings?.panelPosition || 'bottom-right'));
  }

  // --- Modale d'import JSON (remplace prompt() bloquant) ---
  function showImportModal() {
    const existing = document.getElementById('mb-import-modal');
    if (existing) return;

    const overlay = document.createElement('div');
    overlay.id = 'mb-import-modal';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:2147483647;display:flex;align-items:center;justify-content:center;';

    const box = document.createElement('div');
    box.style.cssText = 'background:#1f1f27;color:#fff;padding:20px;border-radius:14px;max-width:500px;width:90%;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;';

    const title = document.createElement('h3');
    title.style.cssText = 'margin:0 0 10px;font-size:14px;color:#f16522;';
    title.innerText = '📥 Import JSON de la base de correspondance';
    box.appendChild(title);

    const textarea = document.createElement('textarea');
    textarea.placeholder = 'Colle ton export JSON ici...';
    textarea.style.cssText = 'width:100%;height:150px;background:#33333d;color:#fff;border:1px solid #f16522;border-radius:8px;padding:8px;font-size:12px;font-family:monospace;resize:vertical;box-sizing:border-box;';
    box.appendChild(textarea);

    const status = document.createElement('p');
    status.style.cssText = 'margin:8px 0 0;font-size:12px;min-height:16px;';
    box.appendChild(status);

    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:12px;';

    const cancelBtn = document.createElement('button');
    cancelBtn.innerText = 'Annuler';
    cancelBtn.style.cssText = 'padding:8px 16px;background:#34495e;color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:600;';
    cancelBtn.onclick = () => overlay.remove();

    const importBtn = document.createElement('button');
    importBtn.innerText = 'Importer';
    importBtn.style.cssText = 'padding:8px 16px;background:#27ae60;color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:600;';
    importBtn.onclick = async () => {
      try {
        const parsed = JSON.parse(textarea.value);
        await window.MangaBridgeStorage.setDB(parsed);
        status.style.color = '#39dc84';
        status.innerText = '✅ Import réussi !';
        setTimeout(() => {
          overlay.remove();
          resetProcessedCards();
          processAllPendingCards();
        }, 800);
      } catch (e) {
        status.style.color = '#e74c3c';
        status.innerText = "❌ JSON invalide. Vérifie le format.";
      }
    };
    importBtn.onkeydown = (e) => { if (e.key === 'Enter') importBtn.onclick(); };

    btnRow.appendChild(cancelBtn);
    btnRow.appendChild(importBtn);
    box.appendChild(btnRow);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
    textarea.focus();
  }

  function injectControlPanel() {
    if (document.getElementById('mb-control-panel')) return;

    const panel = document.createElement('div');
    panel.id = 'mb-control-panel';

    const filterBtn = document.createElement('button');
    filterBtn.id = 'mb-filter-btn';
    filterBtn.className = 'mb-btn-filter';
    refreshFilterButtonLabel(filterBtn);
    filterBtn.onclick = async () => {
      // On écrit uniquement dans le storage ici — on NE met PAS à jour le
      // label/la classe localement en parallèle. L'affichage est mis à jour
      // uniquement par le listener chrome.storage.onChanged (source de
      // vérité unique) : avoir deux chemins de mise à jour concurrents
      // (optimiste ici + listener) causait une course qui pouvait laisser
      // le bouton dans un état visuellement désynchronisé du storage réel.
      const current = await window.MangaBridgeStorage.getSettings();
      await window.MangaBridgeStorage.setSettings({ hideOwned: !current.hideOwned });
    };
    panel.appendChild(filterBtn);

    if (selectorSets.length > 0) {
      const syncWrapper = document.createElement('div');
      syncWrapper.className = 'mb-sync-wrapper';

      const syncBtn = document.createElement('button');
      syncBtn.className = 'mb-btn-sync';
      syncBtn.innerText = '🔄 Synchro';
      syncBtn.onclick = () => launchSync(syncBtn);

      // Bouton Import manuel : cache derrière le bouton Synchro, révélé après
      // 3s de survol — secours si la synchro automatique échoue.
      const importBtn = document.createElement('button');
      importBtn.className = 'mb-btn-import';
      importBtn.innerText = '📥 Import BDD';
      importBtn.onclick = () => showImportModal();

      let hoverTimer = null;
      syncWrapper.addEventListener('mouseenter', () => {
        hoverTimer = setTimeout(() => {
          syncBtn.style.display = 'none';
          importBtn.style.display = 'inline-block';
        }, 3000);
      });
      syncWrapper.addEventListener('mouseleave', () => {
        clearTimeout(hoverTimer);
        syncBtn.style.display = '';
        importBtn.style.display = 'none';
      });

      syncWrapper.appendChild(syncBtn);
      syncWrapper.appendChild(importBtn);
      panel.appendChild(syncWrapper);

      const addMoreBtn = document.createElement('button');
      addMoreBtn.className = 'mb-btn-learn';
      addMoreBtn.innerText = '🎓 +';
      addMoreBtn.title = 'Ajouter un autre type de case pour ce site';
      addMoreBtn.onclick = () => startLearningMode();
      panel.appendChild(addMoreBtn);
    } else {
      const learnBtn = document.createElement('button');
      learnBtn.className = 'mb-btn-learn';
      learnBtn.innerText = '🎓 Configurer ce site';
      learnBtn.onclick = () => startLearningMode();
      panel.appendChild(learnBtn);
    }

    document.body.appendChild(panel);
    applyPanelPosition();
  }

  function launchSync(btn) {
    const originalLabel = btn.innerText;
    btn.disabled = true;
    chrome.runtime.sendMessage({ type: 'MB_LAUNCH_SYNC' }, () => {});

    const timeoutMs = 50000;
    const startTime = Date.now();
    const countdown = setInterval(() => {
      const remaining = Math.max(0, Math.ceil((timeoutMs - (Date.now() - startTime)) / 1000));
      btn.innerText = `⏳ Synchro... ${remaining}s`;
      if (remaining <= 0) clearInterval(countdown);
    }, 1000);

    const listener = (changes, area) => {
      if (area !== 'local') return;
      if (changes[window.MB_KEYS.SYNC_STATE]) {
        const state = changes[window.MB_KEYS.SYNC_STATE].newValue;
        if (state?.status === 'done') {
          clearInterval(countdown);
          chrome.storage.onChanged.removeListener(listener);
          btn.innerText = '✅ Synchronisé !';
          setTimeout(() => {
            btn.innerText = originalLabel;
            btn.disabled = false;
            resetProcessedCards();
            processAllPendingCards();
          }, 1200);
        } else if (state?.status === 'error') {
          clearInterval(countdown);
          chrome.storage.onChanged.removeListener(listener);
          btn.innerText = originalLabel;
          btn.disabled = false;
          window.MangaBridgeMascot.showBubble("❌ La synchro Mangacollec a échoué (vérifie le pseudo et la connexion sur mangacollec.com).", { autoHideMs: 6000 });
        }
      }
    };
    chrome.storage.onChanged.addListener(listener);

    setTimeout(() => {
      chrome.storage.onChanged.removeListener(listener);
      clearInterval(countdown);
      if (btn.disabled) {
        btn.innerText = originalLabel;
        btn.disabled = false;
      }
    }, timeoutMs + 2000);
  }

  // ==========================================
  // TRAITEMENT DES CARTES
  // ==========================================
  function extractCardData(card, set) {
    let titleEls = [card];
    if (set.titleSelector) {
      if (set.titleConcat) {
        // Le titre est réparti sur plusieurs éléments partageant ce même
        // sélecteur (ex: nom de série + "Tome N" dans deux divs séparées) —
        // explicitement activé pour CE set lors de l'apprentissage, car ce
        // comportement casse d'autres sites où le même sélecteur capture
        // aussi le prix/la date.
        const found = Array.from(card.querySelectorAll(set.titleSelector));
        if (found.length) titleEls = found;
      } else {
        titleEls = [card.querySelector(set.titleSelector) || card];
      }
    }
    const rawTitle = titleEls
      .map(el => (el.innerText || '').trim().split('\n')[0].trim())
      .filter(Boolean)
      .join(' ');
    const firstEl = titleEls[0];
    const linkEl = firstEl.closest?.('a') || firstEl.querySelector?.('a') || card.querySelector('a');
    const url = window.MangaBridgeStorage.cleanUrl(linkEl ? linkEl.href : (location.href + '#' + rawTitle));
    return { rawTitle, url };
  }

  // Mots qui, juste avant un numéro final, signifient que ce numéro N'EST
  // PAS un numéro de tome (saison, intégrale, coffret...) — on ne veut pas
  // que "Naruto Saison 2" ou "One Piece Intégrale 3" soient pris pour le
  // tome 2 / tome 3.
  const MB_NON_VOLUME_WORDS = /\b(saison|season|integrale|int\.?|coffret|box|edition|é?dition)\s*$/i;

  function extractVolumeNumber(rawTitle) {
    // 1) Cas standard : un mot-clé de tome est présent et suivi d'un numéro.
    const keywordMatch = rawTitle.match(/\b(?:tome|vol\.?|volume|t)\s*(\d+)\b/i);
    if (keywordMatch) return String(parseInt(keywordMatch[1], 10));

    // 2) Cas de secours : aucun mot-clé "tome/vol/volume/t" séparé du titre,
    // mais un numéro est collé directement au nom (ex: "Boruto 1 (neuf)").
    // On retire d'abord le bruit entre parenthèses, puis on regarde si le
    // titre se termine par un numéro isolé — sauf si ce numéro suit un mot
    // d'édition (saison/intégrale/coffret...), auquel cas ce n'est pas un
    // numéro de tome.
    const stripped = rawTitle.replace(/\(.*?\)/g, ' ').replace(/\s+/g, ' ').trim();
    const trailingMatch = stripped.match(/(\d+)\s*$/);
    if (trailingMatch) {
      const before = stripped.slice(0, trailingMatch.index).trim();
      if (before.length > 0 && !MB_NON_VOLUME_WORDS.test(before)) {
        return String(parseInt(trailingMatch[1], 10));
      }
    }
    return null;
  }

  function renderBadge(card, rawTitle, url, activeKey, score, db, isAutoMatch) {
    const badge = document.createElement('div');
    badge.className = 'mb-badge';

    if (activeKey && db[activeKey]) {
      const manga = db[activeKey];
      const isAnnex = window.MangaBridgeMatcher.MatchingEngine.annexDBKeys.has(activeKey);

      // Construction DOM sécurisée (pas d'innerHTML pour des données utilisateur)
      const labelDiv = document.createElement('div');
      labelDiv.className = 'mb-badge-label';
      if (isAnnex) {
        const annexSpan = document.createElement('span');
        annexSpan.className = 'mb-badge-annex';
        annexSpan.textContent = '📚';
        labelDiv.appendChild(annexSpan);
      }
      const pctSpan = document.createElement('span');
      pctSpan.className = 'mb-badge-pct';
      pctSpan.textContent = `${Math.round(score * 100)}%`;
      labelDiv.appendChild(pctSpan);
      const nomSpan = document.createElement('span');
      nomSpan.className = 'mb-badge-nom';
      nomSpan.textContent = manga.nom || 'Sans nom';
      labelDiv.appendChild(nomSpan);
      const ratioSpan = document.createElement('span');
      ratioSpan.className = 'mb-badge-ratio';
      ratioSpan.textContent = `(${manga.ratio || '0/0'})`;
      labelDiv.appendChild(ratioSpan);
      badge.appendChild(labelDiv);
      const dotDiv = document.createElement('div');
      dotDiv.className = 'mb-badge-dot matched';
      badge.appendChild(dotDiv);

      let isOwned = false;
      const volumeNumber = extractVolumeNumber(rawTitle);
      const ratioParts = (manga.ratio || '0/0').split('/');
      const ratioOwned = parseInt(ratioParts[0], 10) || 0;
      const ratioTotal = parseInt(ratioParts[1], 10) || 0;
      const isFullyOwned = ratioOwned > 0 && ratioOwned === ratioTotal;

      if (isFullyOwned) {
        // Collection complète (y compris les séries à un seul tome) : peu
        // importe qu'on ait détecté ou non un numéro de tome dans le titre,
        // il ne peut de toute façon pas manquer un tome.
        isOwned = true;
      } else if (volumeNumber && manga.tomes) {
        const normalized = manga.tomes.map(t => String(parseInt(t, 10)));
        if (normalized.includes(volumeNumber)) isOwned = true;
      }

      if (isOwned) {
        card.setAttribute('data-mb-owned', 'true');
      }
    } else {
      // Construction DOM sécurisée (pas d'innerHTML pour des données utilisateur)
      const labelDiv = document.createElement('div');
      labelDiv.className = 'mb-badge-label';
      labelDiv.textContent = `${Math.round(score * 100)}% - ${rawTitle.substring(0, 18)}`;
      badge.appendChild(labelDiv);
      const dotDiv = document.createElement('div');
      dotDiv.className = 'mb-badge-dot none';
      badge.appendChild(dotDiv);
    }

    badge.onclick = (e) => {
      e.stopPropagation();
      e.preventDefault();
      openMenu(card, rawTitle, url, isAutoMatch ? activeKey : null);
    };

    if (getComputedStyle(card).position === 'static') card.style.position = 'relative';
    card.appendChild(badge);

    // Le grisage s'applique à chaque enfant de la carte INDIVIDUELLEMENT, en
    // excluant le badge — un filter/opacity posé sur la carte ENTIÈRE (via
    // CSS sur [data-mb-owned]) grise tout son rendu en un seul bloc, badge
    // compris, sans qu'un enfant puisse s'en exempter. En appliquant la
    // classe enfant par enfant (sauf au badge), le badge reste net et lisible
    // par-dessus la fiche grisée.
    if (card.hasAttribute('data-mb-owned')) {
      Array.from(card.children).forEach(child => {
        if (child !== badge) child.classList.add('mb-owned-dim');
      });
    }
  }

  async function processSingleCard(card, set, state) {
    if (card.hasAttribute('data-mb-status')) return;
    card.setAttribute('data-mb-status', 'processed');

    const { rawTitle, url } = extractCardData(card, set);
    if (!rawTitle) return;

    const cleanGeneric = window.MangaBridgeMatcher.TextProcessor.noiseClean(rawTitle);
    let activeKey = state.aliases[cleanGeneric];
    if (state.confirmed[url] && state.confirmed[url] !== 'IGNORE') activeKey = state.confirmed[url];

    let score = 0;
    let isAutoMatch = false;
    if (!activeKey) {
      const best = window.MangaBridgeMatcher.MatchingEngine.findBestMatch(rawTitle);
      if (best.score >= window.MangaBridgeMatcher.AUTO_MATCH_THRESHOLD) {
        // Le couple [titre du site + entrée BDD] peut avoir été explicitement
        // exclu (bouton "Ignorer ce match") : dans ce cas précis uniquement,
        // on traite ce résultat exactement comme un échec de matching —
        // aucun autre filtrage de l'algorithme, aucune autre clé touchée.
        const excluded = state.excludedPairs[window.MangaBridgeStorage.pairKey(cleanGeneric, best.key)];
        if (!excluded) {
          activeKey = best.key;
          isAutoMatch = true;
        }
      }
      score = best.score;
    } else {
      const entry = window.MangaBridgeMatcher.MatchingEngine.optimizedDB.find(e => e.key === activeKey);
      if (entry) score = window.MangaBridgeMatcher.MatchingEngine.calculateScore(rawTitle, entry);
    }

    renderBadge(card, rawTitle, url, activeKey, score, state.db, isAutoMatch);
  }

  // Nettoyage complet avant retraitement : sans ça, les anciens badges
  // s'accumulaient (un nouveau était ajouté à chaque appel sans retirer
  // l'ancien) et data-mb-owned / .mb-owned-dim pouvaient rester bloqués sur
  // un état périmé après une synchro ou un changement d'ignore/profil.
  function resetProcessedCards() {
    document.querySelectorAll('.mb-badge').forEach(b => b.remove());
    document.querySelectorAll('.mb-owned-dim').forEach(el => el.classList.remove('mb-owned-dim'));
    document.querySelectorAll('[data-mb-status]').forEach(c => c.removeAttribute('data-mb-status'));
    document.querySelectorAll('[data-mb-owned]').forEach(c => c.removeAttribute('data-mb-owned'));
  }

  async function processAllPendingCards() {
    if (selectorSets.length === 0) return;

    const [db, annexDB, conf, ali, excludedPairs] = await Promise.all([
      window.MangaBridgeStorage.getDB(),
      window.MangaBridgeStorage.getAnnexDB(),
      window.MangaBridgeStorage.getConfirmed(HOSTNAME),
      window.MangaBridgeStorage.getAliases(HOSTNAME),
      window.MangaBridgeStorage.getExcludedPairs(HOSTNAME)
    ]);
    confirmed = conf;
    aliases = ali;
    window.MangaBridgeMatcher.MatchingEngine.initialize(db, confirmed, annexDB);
    // Fusionner db + annexDB pour que renderBadge/openMenu trouvent les entrées annexes
    const mergedDB = Object.assign({}, annexDB, db); // db prioritaire en cas de clash
    const state = { db: mergedDB, confirmed, aliases, excludedPairs };

    for (const set of selectorSets) {
      let cards;
      try {
        cards = Array.from(document.querySelectorAll(set.cardSelector)).filter(c => !c.hasAttribute('data-mb-status'));
      } catch (e) { continue; }
      if (cards.length === 0) continue;

      let index = 0;
      const batch = (deadline) => {
        while ((deadline.timeRemaining() > 0 || deadline.didTimeout) && index < cards.length) {
          processSingleCard(cards[index], set, state);
          index++;
        }
        if (index < cards.length) requestIdleCallback(batch);
      };
      if (window.requestIdleCallback) requestIdleCallback(batch);
      else cards.forEach(c => processSingleCard(c, set, state));
    }
  }

  // ==========================================
  // MENU DE CORRECTION (recherche / suggestions / ignorer)
  // ==========================================
  async function openMenu(card, rawTitle, url, activeKey) {
    document.getElementById('mb-menu')?.remove();
    const [db, annexDB] = await Promise.all([
      window.MangaBridgeStorage.getDB(),
      window.MangaBridgeStorage.getAnnexDB()
    ]);
    const mergedDB = Object.assign({}, annexDB, db); // db prioritaire en cas de clash
    const annexKeys = window.MangaBridgeMatcher.MatchingEngine.annexDBKeys;

    const menu = document.createElement('div');
    menu.id = 'mb-menu';
    const rect = card.getBoundingClientRect();
    menu.style.position = 'fixed';
    menu.style.top = Math.max(8, rect.top + 34) + 'px';
    menu.style.left = Math.max(8, rect.left + 5) + 'px';
    menu.style.width = Math.max(220, rect.width - 10) + 'px';
    menu.style.right = 'auto';

    // --- Input de recherche ---
    const searchWrap = document.createElement('div');
    searchWrap.style.position = 'relative';
    const input = document.createElement('input');
    input.placeholder = '🔍 Rechercher dans la collection...';
    searchWrap.appendChild(input);
    menu.appendChild(searchWrap);

    // --- Zone de résultats (recherche OU suggestions) ---
    const resultsArea = document.createElement('div');
    resultsArea.className = 'mb-results-area';
    resultsArea.style.maxHeight = '200px';
    resultsArea.style.overflowY = 'auto';
    resultsArea.style.marginTop = '8px';
    menu.appendChild(resultsArea);

    // Remplir avec les suggestions au départ
    const renderSuggestions = () => {
      resultsArea.innerHTML = '';
      const suggTitle = document.createElement('div');
      suggTitle.style.cssText = 'font-size:11px; color:#aaa; padding:4px 6px;';
      suggTitle.innerText = 'Suggestions :';
      resultsArea.appendChild(suggTitle);
      window.MangaBridgeMatcher.MatchingEngine.suggestions(rawTitle, 5).forEach(s => {
        const item = document.createElement('div');
        item.style.cssText = 'padding:6px 8px; cursor:pointer; font-size:12px; color:white; border-bottom:1px solid rgba(255,255,255,0.08);';
        const isAnnex = annexKeys.has(s.key);
        item.innerText = `${isAnnex ? '📚 ' : ''}${Math.round(s.score * 100)}% - ${formatTitle(mergedDB[s.key])}`;
        item.onmouseenter = () => item.style.background = 'rgba(241,101,34,0.18)';
        item.onmouseleave = () => item.style.background = '';
        item.onclick = () => saveAlias(rawTitle, s.key);
        resultsArea.appendChild(item);
      });
    };
    renderSuggestions();

    // Recherche au clavier
    const doSearch = () => {
      const val = input.value.toLowerCase();
      resultsArea.innerHTML = '';
      if (val.length < 2) { renderSuggestions(); return; }
      const matches = Object.keys(mergedDB).filter(k => mergedDB[k].nom?.toLowerCase().includes(val)).slice(0, 20);
      if (matches.length) {
        matches.forEach(k => {
          const item = document.createElement('div');
          item.style.cssText = 'padding:6px 8px; cursor:pointer; font-size:12px; color:white; border-bottom:1px solid rgba(255,255,255,0.08);';
          const isAnnex = annexKeys.has(k);
          item.innerText = `${isAnnex ? '📚 ' : ''}${formatTitle(mergedDB[k])}`;
          item.onmouseenter = () => item.style.background = 'rgba(241,101,34,0.18)';
          item.onmouseleave = () => item.style.background = '';
          item.onclick = () => saveAlias(rawTitle, k);
          resultsArea.appendChild(item);
        });
      } else {
        const empty = document.createElement('div');
        empty.style.cssText = 'padding:6px 8px; font-size:12px; color:#8a8a95; font-style:italic;';
        empty.innerText = 'Rien trouvé.';
        resultsArea.appendChild(empty);
      }
    };

    input.oninput = doSearch;

    // Interception des touches quand le menu est ouvert
    menu.addEventListener('keydown', (e) => {
      // Si on est déjà dans l'input, on ne fait rien (l'input gère tout)
      if (document.activeElement === input) return;
      // Ignorer les touches de navigation/contrôle
      if (e.ctrlKey || e.altKey || e.metaKey) return;
      // Touches non-imprimantes → on les laisse passer
      if (e.key === 'Escape' || e.key === 'Tab' || e.key === 'ArrowUp' || e.key === 'ArrowDown') return;
      // Toute autre touche → focus input et laisser passer
      if (e.key.length === 1) {
        e.preventDefault();
        input.focus();
      }
    });

    const actions = document.createElement('div');
    actions.className = 'mb-actions';
    const mkBtn = (txt, color, fn) => {
      const b = document.createElement('button');
      b.innerText = txt;
      b.style.background = color;
      b.onclick = fn;
      return b;
    };
    actions.appendChild(mkBtn('🗑️ Effacer', '#c0392b', async () => {
      const conf = await window.MangaBridgeStorage.getConfirmed(HOSTNAME);
      delete conf[url];
      await window.MangaBridgeStorage.setConfirmed(HOSTNAME, conf);
      const ali = await window.MangaBridgeStorage.getAliases(HOSTNAME);
      delete ali[window.MangaBridgeMatcher.TextProcessor.noiseClean(rawTitle)];
      await window.MangaBridgeStorage.setAliases(HOSTNAME, ali);
      menu.remove();
      resetProcessedCards();
      processAllPendingCards();
    }));
    if (activeKey) {
      // N'apparaît QUE si un matching automatique a été trouvé et appliqué.
      // N'enregistre PAS un blocage de la série entière : uniquement le
      // couple précis [ce titre de site + cette entrée BDD]. Un autre titre
      // du site qui matcherait légitimement la même entrée BDD n'est pas
      // affecté, et le matching manuel reste totalement indépendant.
      actions.appendChild(mkBtn('🚫 Ignorer ce match', '#7f8c8d', async () => {
        const cleanGeneric = window.MangaBridgeMatcher.TextProcessor.noiseClean(rawTitle);
        const db = await window.MangaBridgeStorage.getDB();
        await window.MangaBridgeStorage.excludePair(HOSTNAME, cleanGeneric, activeKey, rawTitle, db[activeKey]?.nom);
        menu.remove();
        resetProcessedCards();
        processAllPendingCards();
      }));
    }
    actions.appendChild(mkBtn('❌ Fermer', '#34495e', () => menu.remove()));
    menu.appendChild(actions);

    document.body.appendChild(menu);
    // Focus automatique APRES ajout au DOM
    input.focus();
    // Un scroll DANS le menu (molette sur la liste de résultats/suggestions)
    // déclenche aussi un évènement 'scroll' capté ici puisque l'écouteur est
    // sur `window` en phase de capture — sans ce garde-fou, faire défiler la
    // liste de résultats refermait immédiatement tout le menu.
    const closeOnScroll = (e) => {
      if (menu.contains(e.target)) return;
      menu.remove();
      window.removeEventListener('scroll', closeOnScroll, true);
    };
    window.addEventListener('scroll', closeOnScroll, true);
  }

  function formatTitle(manga) {
    if (!manga) return 'Inconnu';
    return `${manga.nom || 'Sans nom'}${manga.edition ? ` [${manga.edition}]` : ''}${manga.publisher ? ` | Ed: ${manga.publisher}` : ''}`;
  }

  async function saveAlias(rawTitle, key) {
    const ali = await window.MangaBridgeStorage.getAliases(HOSTNAME);
    ali[window.MangaBridgeMatcher.TextProcessor.noiseClean(rawTitle)] = key;
    await window.MangaBridgeStorage.setAliases(HOSTNAME, ali);
    document.getElementById('mb-menu')?.remove();
    resetProcessedCards();
    processAllPendingCards();
  }

  // ==========================================
  // INITIALISATION
  // ==========================================
  let siteEnabled = false;
  let mbObserver = null; // MutationObserver — stocké pour pouvoir le déconnecter

  async function init() {
    try {
      settings = await window.MangaBridgeStorage.getSettings();
      selectorSets = await window.MangaBridgeStorage.getSelectorSets(HOSTNAME);
      siteEnabled = await window.MangaBridgeStorage.isSiteEnabled(HOSTNAME);

      const customNoiseWords = await window.MangaBridgeStorage.getCustomNoiseWords();
      window.MangaBridgeMatcher.TextProcessor.setCustomNoiseWords(customNoiseWords);

      if (settings.hideOwned) document.body.classList.add('mb-hide-owned');

      if (siteEnabled) {
        injectControlPanel();
        if (selectorSets.length > 0) await processAllPendingCards();
      }

      let debounce = null;
      mbObserver = new MutationObserver((mutations) => {
        if (!siteEnabled) return;
        if (mutations.some(m => m.addedNodes.length > 0)) {
          clearTimeout(debounce);
          debounce = setTimeout(() => { if (selectorSets.length > 0) processAllPendingCards(); }, 80);
        }
      });
      mbObserver.observe(document.body, { childList: true, subtree: true });

      chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      if (changes[window.MB_KEYS.DB] && siteEnabled) {
        resetProcessedCards();
        processAllPendingCards();
      }
      if (changes[window.MB_KEYS.EXCLUDED_PAIRS_PREFIX + HOSTNAME] && siteEnabled) {
        resetProcessedCards();
        processAllPendingCards();
      }
      if (changes[window.MB_KEYS.CUSTOM_NOISE_WORDS]) {
        window.MangaBridgeMatcher.TextProcessor.setCustomNoiseWords(changes[window.MB_KEYS.CUSTOM_NOISE_WORDS].newValue || []);
        if (siteEnabled) {
          resetProcessedCards();
          processAllPendingCards();
        }
      }
      if (changes[window.MB_KEYS.SETTINGS]) {
        const s = changes[window.MB_KEYS.SETTINGS].newValue;
        if (s) {
          settings = s;
          document.body.classList.toggle('mb-hide-owned', !!s.hideOwned);
          refreshFilterButtonLabel();
          applyPanelPosition();
        }
      }
      if (changes[window.MB_KEYS.ENABLED_SITES]) {
        const nowEnabled = !!(changes[window.MB_KEYS.ENABLED_SITES].newValue || {})[HOSTNAME];
        if (nowEnabled && !siteEnabled) {
          siteEnabled = true;
          injectControlPanel();
          if (selectorSets.length > 0) processAllPendingCards();
        } else if (!nowEnabled && siteEnabled) {
          siteEnabled = false;
          document.getElementById('mb-control-panel')?.remove();
          resetProcessedCards();
          // Déconnecter le MutationObserver pour éviter une fuite mémoire
          if (mbObserver) { mbObserver.disconnect(); mbObserver = null; }
        }
      }
      if (changes[window.MB_KEYS.PROFILES] && siteEnabled) {
        window.MangaBridgeStorage.getSelectorSets(HOSTNAME).then(sets => {
          selectorSets = sets;
          resetProcessedCards();
          if (selectorSets.length > 0) processAllPendingCards();
        });
      }
    });
    } catch (e) {
      console.error('[MB] Erreur lors de l\'initialisation:', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
