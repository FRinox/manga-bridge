// ==========================================
// Manga-Bridge Universal — pont Mangacollec (MONDE ISOLÉ)
// ==========================================
// Ce script a accès à chrome.storage / chrome.runtime, mais PAS au vrai
// window.fetch de la page (c'est mangacollec-inject.js, exécuté en MAIN
// world, qui s'en charge). Il écoute l'événement 'mb:collection-data'
// dispatché par ce dernier sur `document` — les deux mondes partagent le
// même DOM, donc l'événement traverse la frontière normalement.
(function () {
  'use strict';

  function superClean(str) {
    if (!str) return "";
    return str.toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/\(.*?\)/g, "")
      .replace(/[^a-z0-9]/g, "");
  }

  function yieldToMainThread() {
    if (typeof requestIdleCallback === 'function') {
      return new Promise(resolve => requestIdleCallback(() => resolve(), { timeout: 30 }));
    }
    return new Promise(resolve => setTimeout(resolve, 8));
  }

  async function processCollection(data, onProgress) {
    if (!data) return null;

    // Les éditeurs sont stockés depuis l'écouteur mb:publishers-data
    // (intercepté quand la page /publishers charge, pas dans la réponse collection).
    // Les genres sont stockés depuis l'écouteur mb:kinds-data (page /series?search=).
    // On garde juste les éditeurs déjà connus pour résoudre les noms dans le dbBridge.
    const learnedPublishers = await window.MangaBridgeStorage.getLearnedPublishers();

    const dbBridge = {};
    const ownedVolIds = new Set((data.possessions || []).map(p => p.volume_id));
    const seriesMap = {};
    (data.series || []).forEach(s => { seriesMap[s.id] = s.title; });

    const seriesGroups = {};
    let counter = 0;

    if (data.editions) {
      for (const ed of data.editions) {
        const seriesName = seriesMap[ed.series_id];
        if (!seriesName) continue;

        const edVols = (data.volumes || []).filter(v => v.edition_id === ed.id);
        const owned = edVols
          .filter(v => ownedVolIds.has(v.id))
          .map(v => String(v.number || 1).replace(/^0+/, ''));

        if (owned.length === 0) continue;

        if (!seriesGroups[ed.series_id]) seriesGroups[ed.series_id] = [];
        seriesGroups[ed.series_id].push({
          ed_id: ed.id,
          title: ed.title,
          publisher_id: ed.publisher_id,
          owned: [...new Set(owned)].sort((a, b) => a - b),
          total: Math.max(parseInt(ed.volumes_count) || 0, parseInt(ed.last_volume_number) || 0)
        });

        counter++;
        if (counter % 15 === 0) { if (onProgress) onProgress(counter); await yieldToMainThread(); }
      }
    }

    if (data.boxes && data.box_editions) {
      for (const box of data.boxes) {
        const boxEd = data.box_editions.find(be => be.id === box.box_edition_id);
        if (boxEd) {
          const mangaTitle = boxEd.title || "Inconnu";
          const boxDetail = box.title || "Coffret";
          const combinedName = `${mangaTitle} ${boxDetail}`;
          const cleanKey = superClean(combinedName);
          dbBridge[cleanKey] = {
            nom: combinedName,
            edition: boxDetail,
            tomes: ["1"],
            ratio: "1/1"
          };
        }
        counter++;
        if (counter % 15 === 0) { if (onProgress) onProgress(counter); await yieldToMainThread(); }
      }
    }

    const sIds = Object.keys(seriesGroups);
    for (const sId of sIds) {
      const editions = seriesGroups[sId];
      const sName = seriesMap[sId];
      const cleanSName = superClean(sName);

      editions.sort((a, b) => {
        const isAStd = !a.title || a.title.toLowerCase().includes('standard');
        const isBStd = !b.title || b.title.toLowerCase().includes('standard');
        return isBStd - isAStd;
      });

      editions.forEach((ed, index) => {
        let suffix = "";
        const isFirstAndStandard = (index === 0 && (!ed.title || ed.title.toLowerCase().includes('standard')));

        if (!isFirstAndStandard && ed.title) {
          const lowT = ed.title.toLowerCase();
          const keywords = ['perfect', 'collector', 'prestige', 'deluxe', 'saison', 'season', 'integrale', 'double'];
          const found = keywords.find(k => lowT.includes(k));
          if (found) {
            if (found === 'saison' || found === 'season') {
              const num = ed.title.match(/\d+/);
              suffix = "saison" + (num ? num[0] : (index + 1));
            } else {
              suffix = found;
            }
          }
        }

        let dbKey = cleanSName + suffix;
        if (dbBridge[dbKey]) {
          suffix = "ed" + (index + 1);
          dbKey = cleanSName + suffix;
          if (dbBridge[dbKey]) {
            const publisherName = learnedPublishers[ed.publisher_id] || "inconnu";
            dbKey = cleanSName + suffix + "_" + superClean(publisherName);
            if (dbBridge[dbKey]) dbKey = dbKey + "_" + Math.floor(Math.random() * 9000 + 1000);
          }
        }

        dbBridge[dbKey] = {
          nom: sName,
          edition: ed.title || "Standard",
          publisher: learnedPublishers[ed.publisher_id] || "Inconnu",
          tomes: ed.owned,
          ratio: `${ed.owned.length}/${ed.total > 0 ? ed.total : '?'}`
        };
      });

      counter++;
      if (counter % 15 === 0) { if (onProgress) onProgress(counter); await yieldToMainThread(); }
    }

    const statsAndHistory = await buildStatsAndHistory(data, learnedPublishers);

    return { dbBridge, statsData: statsAndHistory.statsData, historyItems: statsAndHistory.historyItems };
  }

  // Construit les données pour l'onglet "Statistiques & Historique" des
  // options : répartition par éditeur/genre, et liste chronologique de tous
  // les tomes/coffrets possédés (titre, tome, éditeur, date d'ajout).
  async function buildStatsAndHistory(data, learnedPublishers) {
    const { possessions = [], box_possessions = [], volumes = [], editions = [], series = [], kinds = [], publishers = [], boxes = [], box_editions = [] } = data;
    const statsData = { publishers: {}, genres: {} };
    const allPoss = [...possessions, ...box_possessions];
    const learnedGenres = await window.MangaBridgeStorage.getLearnedGenres();
    const unresolvedGenreIds = new Set();

    const historyItems = allPoss.map(pos => {
      const itemId = pos.volume_id || pos.box_id;
      const vol = volumes.find(v => String(v.id) === String(itemId));
      const box = boxes.find(b => String(b.id) === String(pos.box_id));
      let pubName = "Éditeur Inconnu", title = "Inconnu", subTitle = "";

      if (vol) {
        const ed = editions.find(e => String(e.id) === String(vol.edition_id));
        const sery = series.find(s => ed && String(s.id) === String(ed.series_id));
        title = sery ? sery.title : "Série Inconnue";
        subTitle = "Tome " + (vol.number || "?");
        if (ed) {
          const pId = String(ed.publisher_id);
          const apiPub = publishers.find(p => String(p.id) === pId);
          pubName = apiPub ? apiPub.title : (learnedPublishers[pId] || "Éditeur Inconnu");
          if (sery && sery.kinds_ids) {
            sery.kinds_ids.forEach(kId => {
              // Priorité au mapping importé manuellement (learnedGenres) —
              // l'API collection ne fournit pas de liste fiable id -> nom
              // pour les genres, contrairement aux éditeurs. On garde trace
              // des ID non résolus pour faciliter un futur import.
              const idStr = String(kId);
              const genreName = learnedGenres[idStr]
                || kinds.find(k => String(k.id) === idStr)?.title;
              if (genreName) {
                statsData.genres[genreName] = (statsData.genres[genreName] || 0) + 1;
              } else {
                unresolvedGenreIds.add(idStr);
                statsData.genres[`ID inconnu : ${idStr}`] = (statsData.genres[`ID inconnu : ${idStr}`] || 0) + 1;
              }
            });
          }
        }
      } else if (box) {
        const boxEd = box_editions.find(be => be.id === box.box_edition_id);
        title = (boxEd && boxEd.title) || box.title || box.name || "Coffret";
        subTitle = "Coffret";
        const bPId = String(box.publisher_id || (boxEd && boxEd.publisher_id));
        const apiPub = publishers.find(p => String(p.id) === bPId);
        pubName = apiPub ? apiPub.title : (learnedPublishers[bPId] || "Éditeur Inconnu");
      }

      statsData.publishers[pubName] = (statsData.publishers[pubName] || 0) + 1;
      return {
        title, subTitle, pub: pubName,
        dateStr: new Date(pos.created_at).toLocaleDateString('fr-FR'),
        timestamp: new Date(pos.created_at).getTime()
      };
    }).sort((a, b) => b.timestamp - a.timestamp);

    const seriesKindsMap = {};
    series.forEach(s => {
      if (s.id && Array.isArray(s.kinds_ids) && s.kinds_ids.length > 0) {
        seriesKindsMap[String(s.id)] = s.kinds_ids;
      }
    });

    return { statsData, historyItems, unresolvedGenreIds: [...unresolvedGenreIds], seriesKindsMap };
  }

  function showBanner(text) {
    const render = () => {
      let el = document.getElementById('mb-sync-banner');
      if (!el) {
        el = document.createElement('div');
        el.id = 'mb-sync-banner';
        el.style.cssText = "position:fixed; top:10px; left:50%; transform:translateX(-50%); z-index:2147483647; background:#27ae60; color:white; padding:10px 18px; border-radius:10px; font-family:sans-serif; font-weight:bold; box-shadow:0 4px 15px rgba(0,0,0,0.4);";
        document.body.appendChild(el);
      }
      el.innerText = text;
    };
    if (document.body) render();
    else document.addEventListener('DOMContentLoaded', render, { once: true });
  }

  // Le bridge s'exécute sur toutes les pages Mangacollec.
  // Chaque étape de synchro affiche son propre banner vert —
  // mais uniquement si la synchro a été explicitement lancée.
  const isCollectionPage = /\/user\/[^/]+\/collection/.test(location.pathname);
  const isPublishersPage = /\/publishers/.test(location.pathname);
  const isKindsPage = /\/series/.test(location.pathname);

  // Affiche le banner d'attente seulement si l'état de synchro est 'pending'
  (async () => {
    const states = await window.MangaBridgeStorage.getSyncState();
    const pubStates = await window.MangaBridgeStorage.getPublisherSyncState();
    const kindsStates = await window.MangaBridgeStorage.getKindsSyncState();

    if (isCollectionPage && states.status === 'pending') {
      showBanner('⏳ En attente des données de la collection...');
    }
    if (isPublishersPage && pubStates.status === 'pending') {
      showBanner('⏳ En attente de la liste des éditeurs...');
    }
    if (isKindsPage && kindsStates.status === 'pending') {
      showBanner('⏳ En attente de la liste des genres...');
    }
  })();

  document.addEventListener('mb:collection-data', async (e) => {
    const data = e.detail;
    if (!data || !data.possessions) return;

    // Ne traite les données que si la synchro a été explicitement lancée via le bouton
    const state = await window.MangaBridgeStorage.getSyncState();
    if (state.status !== 'pending') return;
    try {
      const total = (data.editions?.length || 0) + (data.boxes?.length || 0);
      const result = await processCollection(data, (count) => {
        if (isCollectionPage) showBanner(`⏳ Traitement de la collection en cours... ${count}${total ? ' / ' + total : ''} élément(s) traités`);
      });
      await window.MangaBridgeStorage.setDB(result.dbBridge);
      await window.MangaBridgeStorage.setStatsData(result.statsData);
      await window.MangaBridgeStorage.setHistoryItems(result.historyItems);
      await window.MangaBridgeStorage.setUnresolvedGenreIds(result.unresolvedGenreIds);
      await window.MangaBridgeStorage.setSeriesKindsMap(result.seriesKindsMap);
      await window.MangaBridgeStorage.setSyncState({ status: 'done', finishedAt: Date.now() });
      if (isCollectionPage) showBanner(`✅ Synchro terminée (${Object.keys(result.dbBridge).length} entrées). Fermeture...`);
      chrome.runtime.sendMessage({ type: 'MB_SYNC_TAB_DONE' });
    } catch (err) {
      console.error('[Manga-Bridge] Erreur traitement collection', err);
      await window.MangaBridgeStorage.setSyncState({ status: 'error' });
      if (isCollectionPage) showBanner('❌ Erreur lors du traitement de la collection (voir la console).');
    }
  });

  document.addEventListener('mb:collection-error', async () => {
    await window.MangaBridgeStorage.setSyncState({ status: 'error' });
    if (isCollectionPage) showBanner('❌ Impossible de récupérer la collection.');
  });

  // ==========================================
  // Écouteur de la liste complète des éditeurs
  // ==========================================
  document.addEventListener('mb:publishers-data', async (e) => {
    const data = e.detail;
    if (!data) return;

    // Ne traite que si la synchro publishers a été explicitement lancée
    const pubState = await window.MangaBridgeStorage.getPublisherSyncState();
    if (pubState.status !== 'pending') return;

    // La réponse peut être un tableau direct ou un objet {publishers: [...]}
    let list = null;
    if (Array.isArray(data)) list = data;
    else if (data && Array.isArray(data.publishers)) list = data.publishers;

    if (list && list.length > 0) {
      const learned = await window.MangaBridgeStorage.getLearnedPublishers();
      let newCount = 0;
      list.forEach(p => {
        if (p && p.id != null && p.title) {
          const idStr = String(p.id);
          if (!learned[idStr]) newCount++;
          learned[idStr] = p.title;
        }
      });
      await window.MangaBridgeStorage.setLearnedPublishers(learned);
      console.log(`[Manga-Bridge] ${list.length} éditeurs stockés depuis l'API (${newCount} nouveaux).`);
      if (isPublishersPage) showBanner(`✅ ${list.length} éditeurs stockés (${newCount} nouveaux). Fermeture...`);
      await window.MangaBridgeStorage.setPublisherSyncState({ status: 'done', finishedAt: Date.now() });
      chrome.runtime.sendMessage({ type: 'MB_PUBLISHER_SYNC_TAB_DONE' });
    }
  });

  document.addEventListener('mb:publishers-error', async () => {
    console.warn('[Manga-Bridge] Impossible de récupérer la liste des éditeurs.');
    if (isPublishersPage) showBanner('❌ Impossible de récupérer la liste des éditeurs.');
    await window.MangaBridgeStorage.setPublisherSyncState({ status: 'error', reason: 'api_error' });
    chrome.runtime.sendMessage({ type: 'MB_PUBLISHER_SYNC_TAB_DONE' });
  });

  // ==========================================
  // Écouteur de la liste complète des genres
  // ==========================================
  document.addEventListener('mb:kinds-data', async (e) => {
    const data = e.detail;
    if (!data) return;

    // Ne traite que si la synchro kinds a été explicitement lancée
    const kindsState = await window.MangaBridgeStorage.getKindsSyncState();
    if (kindsState.status !== 'pending') return;

    // La réponse peut être un tableau direct ou un objet {kinds: [...]}
    let list = null;
    if (Array.isArray(data)) list = data;
    else if (data && Array.isArray(data.kinds)) list = data.kinds;

    if (list && list.length > 0) {
      const learned = await window.MangaBridgeStorage.getLearnedGenres();
      let newCount = 0;
      list.forEach(k => {
        if (k && k.id != null && k.title) {
          const idStr = String(k.id);
          if (!learned[idStr]) newCount++;
          learned[idStr] = k.title;
        }
      });
      await window.MangaBridgeStorage.setLearnedGenres(learned);
      console.log(`[Manga-Bridge] ${list.length} genres stockés depuis l'API (${newCount} nouveaux).`);
      if (isKindsPage) showBanner(`✅ ${list.length} genres stockés (${newCount} nouveaux). Fermeture...`);
      await window.MangaBridgeStorage.setKindsSyncState({ status: 'done', finishedAt: Date.now() });
      chrome.runtime.sendMessage({ type: 'MB_KINDS_SYNC_TAB_DONE' });
    }
  });

  document.addEventListener('mb:kinds-error', async () => {
    console.warn('[Manga-Bridge] Impossible de récupérer la liste des genres.');
    if (isKindsPage) showBanner('❌ Impossible de récupérer la liste des genres.');
    await window.MangaBridgeStorage.setKindsSyncState({ status: 'error', reason: 'api_error' });
    chrome.runtime.sendMessage({ type: 'MB_KINDS_SYNC_TAB_DONE' });
  });

  // ==========================================
  // Détection automatique des résultats de recherche dans le DOM
  // ==========================================
  // On surveille le DOM pour détecter quand les résultats de recherche
  // sont affichés (la page est une SPA React, le contenu est chargé dynamiquement)
  try {
    const isSearchPage = /series\?search=/.test(location.search);
    if (isSearchPage) {
    let searchCompleted = false;

    function checkAndSendResults() {
      if (searchCompleted) return;
      // Cherche les éléments de résultat de recherche
      const seriesRows = document.querySelectorAll('[data-testid^="serie-row-"]');
      if (seriesRows.length > 0) {
        searchCompleted = true;
        // Extraire les titres des résultats
        const titles = [];
        seriesRows.forEach(row => {
          const link = row.querySelector('a[role="link"]');
          if (link) {
            const titleEl = link.querySelector('[dir="auto"]');
            if (titleEl) {
              titles.push(titleEl.textContent.trim());
            }
          }
        });
        // Envoyer au background
        chrome.runtime.sendMessage({
          type: 'MB_SEARCH_RESULTS',
          results: titles
        });
        observer.disconnect(); // Plus besoin d'observer après
      }
    }

    const observer = new MutationObserver(() => {
      checkAndSendResults();
    });

    // Attendre que le DOM soit chargé avant d'observer
    if (document.body) {
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      checkAndSendResults();
    } else {
      // DOM pas encore prêt, attendre
      window.addEventListener('DOMContentLoaded', () => {
        observer.observe(document.body, {
          childList: true,
          subtree: true
        });
        checkAndSendResults();
      });
    }

    // Timeout : si rien détecté après 8s, envoyer un résultat vide
    // (SPA React lente à charger, on donne du temps)
    setTimeout(() => {
      if (!searchCompleted) {
        searchCompleted = true;
        observer.disconnect();
        chrome.runtime.sendMessage({
          type: 'MB_SEARCH_RESULTS',
          results: []
        });
      }
    }, 8000);
    }
  } catch (e) {
    console.error('[MB] Erreur dans le bloc de recherche:', e);
  }

  // Filet de sécurité : si la page n'a jamais fait l'appel /collection
  // (session expirée, redirection...), on ne reste pas bloqué en silence.
  // Uniquement sur la page collection — les pages publishers/kinds ont
  // leur propre timeout géré par le service worker.
  if (isCollectionPage) {
    setTimeout(async () => {
      const state = await window.MangaBridgeStorage.getSyncState();
      if (state.status === 'pending') {
        await window.MangaBridgeStorage.setSyncState({ status: 'error', reason: 'no_api_call' });
        showBanner("❌ Aucun appel à l'API collection détecté après 20s. Es-tu bien connecté ?");
      }
    }, 20000);
  }
})();
