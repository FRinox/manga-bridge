// ==========================================
// Manga-Bridge Universal — capture des genres (pages /series/:id)
// ==========================================
// Contrairement à la synchro collection/éditeurs, ce script ne fait AUCUNE
// interception fetch, n'ouvre ni ne ferme d'onglet : il tourne en silence
// pendant que l'utilisateur navigue normalement sur une fiche série, et
// associe les badges de genre affichés à l'écran (dans leur ordre
// d'affichage) aux kinds_ids de cette série — capturés lors de la dernière
// synchro collection (seriesKindsMap). Même principe que le script
// Tampermonkey d'origine, sans le hack de scraping en plus complexe.
(function () {
  'use strict';

  const GENRE_BADGE_SELECTOR = '.css-146c3p1.r-1enofrn.r-5fcqz0';

  function getSeriesIdFromUrl() {
    const parts = location.pathname.split('/').filter(Boolean);
    // .../series/<id> — l'ID est le dernier segment du chemin
    return parts.length >= 2 ? parts[parts.length - 1] : null;
  }

  async function captureGenres() {
    const seriesId = getSeriesIdFromUrl();
    if (!seriesId) return;

    const kindsMap = await window.MangaBridgeStorage.getSeriesKindsMap();
    const kindsIds = kindsMap[seriesId];
    if (!kindsIds || kindsIds.length === 0) return;

    const badges = document.querySelectorAll(GENRE_BADGE_SELECTOR);
    if (badges.length === 0) return;

    const learned = await window.MangaBridgeStorage.getLearnedGenres();
    let updated = false;

    kindsIds.forEach((id, idx) => {
      const idStr = String(id);
      if (badges[idx] && !learned[idStr]) {
        const name = (badges[idx].innerText || '').trim();
        if (name) {
          learned[idStr] = name;
          updated = true;
        }
      }
    });

    if (updated) {
      await window.MangaBridgeStorage.setLearnedGenres(learned);
      // Genres capturés silencieusement, pas de console.log en production
    }
  }

  let debounceTimer = null;
  const scheduleCapture = () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(captureGenres, 300);
  };

  // Le site est une SPA : navigation entre fiches séries sans rechargement
  // complet de page, donc on observe les mutations du DOM plutôt que de ne
  // capturer qu'une fois au chargement.
  const observer = new MutationObserver(scheduleCapture);
  const startObserving = () => {
    observer.observe(document.body || document.documentElement, { childList: true, subtree: true });
    scheduleCapture();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startObserving);
  } else {
    startObserving();
  }

  // Nettoyage au rechargement de page : déconnecte l'observer pour éviter les fuites
  window.addEventListener('beforeunload', () => observer.disconnect());

  // Changement d'URL en SPA (pushState) : re-déclenche une tentative de
  // capture pour la nouvelle série affichée.
  const originalPushState = history.pushState;
  history.pushState = function (...args) {
    originalPushState.apply(this, args);
    scheduleCapture();
  };
  window.addEventListener('popstate', scheduleCapture);
})();
