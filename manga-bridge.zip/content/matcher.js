// ==========================================
// MangaBridgeMatcher — MatchingEngine
// ==========================================
// Utilise MBTextProcessor et MBMatching depuis shared/matching-utils.js
// (chargé en amont via le manifest). Se concentre sur la logique spécifique
// au content script : initialisation de la DB, matching, suggestions.

// Cache des genres chargé dynamiquement depuis learnedGenres (storage)
let _cachedGenres = [];
// Promise résolue quand les genres sont chargés — permet d'éviter la race
// condition avec MatchingEngine.initialize() dans site-injector.js.
let genresReady = null;

async function loadGenresFromStorage() {
  try {
    const learnedGenres = await MangaBridgeStorage.getLearnedGenres();
    _cachedGenres = learnedGenres ? Object.values(learnedGenres) : [];
  } catch (_) {
    _cachedGenres = [];
  }
}

// Charger les genres au démarrage et exposer la Promise
if (typeof window !== 'undefined') {
  genresReady = loadGenresFromStorage();
}

// Wrapper autour de MBTextProcessor qui injecte dynamiquement les genres
// depuis le cache _cachedGenres (remplace l'ancien MB_DEFAULT_GENRES statique).
const TextProcessor = {
  setCustomNoiseWords(list) {
    MBTextProcessor.setCustomNoiseWords(list);
  },

  noiseClean(str) {
    return MBTextProcessor.noiseClean(str, { genres: _cachedGenres });
  },

  getSortedTokens(cleanedStr) {
    return MBTextProcessor.getSortedTokens(cleanedStr);
  }
};

const MatchingEngine = {
  optimizedDB: [],
  ignoredKeys: new Set(),
  // Marqueur pour savoir si une entrée vient de la base annexes — utile pour
  // afficher un indicateur visuel différent (ex: badge avec icône annexes).
  annexDBKeys: new Set(),

  initialize(db, confirmed, annexDB) {
    this.ignoredKeys.clear();
    this.annexDBKeys.clear();
    Object.keys(confirmed || {}).forEach(url => {
      if (confirmed[url] === "IGNORE") this.ignoredKeys.add(url);
    });

    // Base principale (Mangacollec)
    this.optimizedDB = Object.keys(db || {}).map(key => {
      const entry = db[key];
      const editionStr = (entry.edition || "").toLowerCase();
      if (editionStr.includes('collector') || editionStr.includes('limite')) return null;

      const cleanedName = TextProcessor.noiseClean(entry.nom || "");
      return {
        key,
        original: entry,
        cleanedName,
        sortedTokens: TextProcessor.getSortedTokens(cleanedName),
        isAnnex: false
      };
    }).filter(e => e !== null && e.cleanedName.length >= 3);

    // Base annexes — ajoutée en complément, sans filtrage collector/limite
    // (l'utilisateur sait ce qu'il fait en ajoutant manuellement).
    if (annexDB) {
      Object.keys(annexDB).forEach(key => {
        const entry = annexDB[key];
        const cleanedName = TextProcessor.noiseClean(entry.nom || "");
        if (cleanedName.length >= 3) {
          this.optimizedDB.push({
            key,
            original: entry,
            cleanedName,
            sortedTokens: TextProcessor.getSortedTokens(cleanedName),
            isAnnex: true
          });
          this.annexDBKeys.add(key);
        }
      });
    }
  },

  calculateScore(siteTitle, bddEntry) {
    // Délégué à MBMatching qui utilise _coreScore partagé (Levenshtein + Token Sort Ratio)
    return MBMatching.calculateScoreWithEntry(
      siteTitle,
      bddEntry.cleanedName,
      bddEntry.sortedTokens
    );
  },

  findBestMatch(siteTitle) {
    let best = { key: null, score: 0, length: Infinity };
    for (let i = 0; i < this.optimizedDB.length; i++) {
      const entry = this.optimizedDB[i];
      const score = this.calculateScore(siteTitle, entry);
      const entryNameLength = (entry.original.nom || "").length;
      if (score > best.score) {
        best = { key: entry.key, score, length: entryNameLength };
      } else if (score > 0 && score === best.score && entryNameLength < best.length) {
        best = { key: entry.key, score, length: entryNameLength };
      }
    }
    return best;
  },

  suggestions(siteTitle, limit = 5) {
    return this.optimizedDB
      .map(entry => ({ key: entry.key, score: this.calculateScore(siteTitle, entry), length: (entry.original.nom || "").length }))
      .filter(x => x.score > 0)
      .sort((a, b) => (b.score !== a.score) ? b.score - a.score : a.length - b.length)
      .slice(0, limit);
  }
};

if (typeof window !== 'undefined') {
  window.MangaBridgeMatcher = {
    TextProcessor,
    MatchingEngine,
    genresReady,
    AUTO_MATCH_THRESHOLD: typeof window.MB_AUTO_MATCH_THRESHOLD !== 'undefined' ? window.MB_AUTO_MATCH_THRESHOLD : 0.80
  };
}
