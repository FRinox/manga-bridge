// ==========================================
// Manga-Bridge Universal — interception fetch (MONDE PRINCIPAL)
// ==========================================
// Ce fichier tourne dans le "MAIN world" (contexte JS réel de la page,
// comme un script Tampermonkey classique) — contrairement au reste de
// l'extension qui tourne en "isolated world" et n'a donc PAS accès au
// vrai window.fetch utilisé par le code de mangacollec.com.
// Aucune API chrome.* n'est disponible ici : ce script se contente de
// capturer les réponses des APIs (collection, publishers, kinds) et de
// les transmettre au monde isolé (mangacollec-bridge.js) via des
// CustomEvents sur le document, que les deux mondes partagent.
(function () {
  const originalFetch = window.fetch;
  let collectionHandled = false;
  let publishersHandled = false;
  let kindsHandled = false;
  window.fetch = function (...args) {
    const urlArg = args[0];
    const urlStr = (typeof urlArg === 'string') ? urlArg : ((urlArg && urlArg.url) || '');

    const fetchPromise = originalFetch.apply(this, args);

    // Interception de la collection
    if (!collectionHandled && /\/v2\/user\/[^/]+\/collection/i.test(urlStr)) {
      collectionHandled = true;
      fetchPromise.then(response => {
        response.clone().json().then(data => {
          document.dispatchEvent(new CustomEvent('mb:collection-data', { detail: data }));
        }).catch(err => {
          document.dispatchEvent(new CustomEvent('mb:collection-error', { detail: String(err) }));
        });
      }).catch(err => {
        document.dispatchEvent(new CustomEvent('mb:collection-error', { detail: String(err) }));
      });
    }

    // Interception de la liste complète des éditeurs
    if (!publishersHandled && /\/v2\/publishers/i.test(urlStr)) {
      publishersHandled = true;
      fetchPromise.then(response => {
        response.clone().json().then(data => {
          document.dispatchEvent(new CustomEvent('mb:publishers-data', { detail: data }));
        }).catch(err => {
          document.dispatchEvent(new CustomEvent('mb:publishers-error', { detail: String(err) }));
        });
      }).catch(() => {});
    }

    // Interception de la liste complète des genres
    if (!kindsHandled && /\/v2\/kinds/i.test(urlStr)) {
      kindsHandled = true;
      fetchPromise.then(response => {
        response.clone().json().then(data => {
          document.dispatchEvent(new CustomEvent('mb:kinds-data', { detail: data }));
        }).catch(err => {
          document.dispatchEvent(new CustomEvent('mb:kinds-error', { detail: String(err) }));
        });
      }).catch(() => {});
    }

    return fetchPromise;
  };
})();
