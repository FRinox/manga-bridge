// ==========================================
// Manga-Bridge Universal — service worker
// ==========================================

// Charger les utilitaires de matching partagés (MBTextProcessor, MBMatching, MB_AUTO_MATCH_THRESHOLD, MB_STOPWORDS)
importScripts('shared/matching-utils.js');

let syncTabId = null;
let publisherTabId = null;
let kindsTabId = null;
let searchTabId = null;
const searchResolvers = new Map(); // Map<tabId, resolve> — évite la race condition

// Vérifie si un manga existe sur le site Mangacollec via recherche
function checkMangaOnSite(title) {
  return new Promise(async (resolve) => {
    const url = `https://www.mangacollec.com/series?search=${encodeURIComponent(title)}`;
    chrome.tabs.create({ url, active: true }, async (tab) => {
      searchTabId = tab.id;
      searchResolvers.set(tab.id, resolve);
      try { chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* ignore */ }

      // Attendre que la page soit chargée puis injecter un script de vérification
      try {
        // Attendre que la page soit chargée (status 'complete')
        await new Promise((r) => {
          const checkTab = () => {
            chrome.tabs.get(tab.id, (t) => {
              if (chrome.runtime.lastError) { r(); return; } // onglet fermé
              if (t.status === 'complete') r();
              else setTimeout(checkTab, 500);
            });
          };
          checkTab();
        });

        // Attendre que React ait rendu les résultats (délai de 4s)
        await new Promise(r => setTimeout(r, 4000));

        // Injecter le script dans le monde MAIN pour accéder au DOM de la SPA React
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: 'MAIN',
          func: () => {
            // data-testid="serie-row-..." est directement sur la balise <a>
            const seriesRows = document.querySelectorAll('[data-testid^="serie-row-"]');
            const titles = [];
            seriesRows.forEach(row => {
              const titleEls = row.querySelectorAll('[dir="auto"]');
              if (titleEls.length > 0) {
                titles.push(titleEls[0].textContent.trim());
              }
            });
            return titles;
          }
        });

        const foundTitles = results[0]?.result || [];

        // Matching : comparer le titre recherché avec chaque résultat
        const scoredResults = foundTitles.map(candidate => ({
          title: candidate,
          score: MBMatching.calculateScore(title, candidate)
        })).filter(r => r.score > 0).sort((a, b) => b.score - a.score);

        // Déterminer si le manga existe (seuil 80%)
        const bestMatch = scoredResults[0];
        const exists = bestMatch && bestMatch.score >= MB_AUTO_MATCH_THRESHOLD;

        // Résoudre avec le resolver spécifique à cet onglet
        const resolver = searchResolvers.get(tab.id);
        if (resolver) {
          resolver({ found: exists, bestScore: bestMatch?.score || 0, results: scoredResults });
          searchResolvers.delete(tab.id);
        }

        // Fermer l'onglet après 2s
        setTimeout(async () => {
          if (searchTabId === tab.id) {
            try { await chrome.tabs.remove(tab.id); } catch (e) { /* déjà fermé */ }
            searchTabId = null;
          }
        }, 2000);
      } catch (e) {
        console.error('[MB] Erreur recherche manga:', e);
        const resolver = searchResolvers.get(tab.id);
        if (resolver) {
          resolver({ found: false, error: 'injection_failed' });
          searchResolvers.delete(tab.id);
        }
        try { await chrome.tabs.remove(tab.id); } catch (e) { /* déjà fermé */ }
        searchTabId = null;
      }
    });
  });
}

// Vérifie si les publishers sont déjà stockés et saute l'étape si c'est le cas.
async function launchPublisherSync() {
  const r = await chrome.storage.local.get('learnedPublishers');
  const publishers = r.learnedPublishers || {};
  if (Object.keys(publishers).length > 0) {
    // Déjà stockés → on passe directement aux kinds
    await chrome.storage.local.set({ publisherSyncState: { status: 'done', finishedAt: Date.now() } });
    launchKindsSync();
    return;
  }

  await chrome.storage.local.set({ publisherSyncState: { status: 'pending', startedAt: Date.now() } });

  const url = 'https://www.mangacollec.com/publishers?1';
  const tab = await chrome.tabs.create({ url, active: true });
  publisherTabId = tab.id;
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* ignore */ }

  setTimeout(async () => {
    if (publisherTabId === tab.id) {
      const r2 = await chrome.storage.local.get('publisherSyncState');
      if (r2.publisherSyncState?.status === 'pending') {
        await chrome.storage.local.set({ publisherSyncState: { status: 'error', reason: 'timeout' } });
      }
      try { await chrome.tabs.remove(tab.id); } catch (e) { /* déjà fermé */ }
      publisherTabId = null;
      // Reset tous les états en cas de timeout
      await chrome.storage.local.set({
        syncState: { status: 'idle' },
        publisherSyncState: { status: 'idle' },
        kindsSyncState: { status: 'idle' }
      });
    }
  }, 25000);
}

// Vérifie si les kinds sont déjà stockés et saute l'étape si c'est le cas.
async function launchKindsSync() {
  const r = await chrome.storage.local.get('learnedGenres');
  const genres = r.learnedGenres || {};
  if (Object.keys(genres).length > 0) {
    // Déjà stockés → on passe directement à la collection
    await chrome.storage.local.set({ kindsSyncState: { status: 'done', finishedAt: Date.now() } });
    launchCollectionSync();
    return;
  }

  await chrome.storage.local.set({ kindsSyncState: { status: 'pending', startedAt: Date.now() } });

  const url = 'https://www.mangacollec.com/series?search=&_kinds=1';
  const tab = await chrome.tabs.create({ url, active: true });
  kindsTabId = tab.id;
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* ignore */ }

  setTimeout(async () => {
    if (kindsTabId === tab.id) {
      const r2 = await chrome.storage.local.get('kindsSyncState');
      if (r2.kindsSyncState?.status === 'pending') {
        await chrome.storage.local.set({ kindsSyncState: { status: 'error', reason: 'timeout' } });
      }
      try { await chrome.tabs.remove(tab.id); } catch (e) { /* déjà fermé */ }
      kindsTabId = null;
      // Reset tous les états en cas de timeout
      await chrome.storage.local.set({
        syncState: { status: 'idle' },
        publisherSyncState: { status: 'idle' },
        kindsSyncState: { status: 'idle' }
      });
    }
  }, 25000);
}

// Récupère la collection de l'utilisateur (dernière étape)
async function launchCollectionSync() {
  const r = await chrome.storage.local.get('settings');
  const settings = r.settings || {};
  const username = settings.mangacollecUsername;

  await chrome.storage.local.set({ syncState: { status: 'pending', startedAt: Date.now() } });

  const url = `https://www.mangacollec.com/user/${encodeURIComponent(username)}/collection?1`;
  const tab = await chrome.tabs.create({ url, active: true });
  syncTabId = tab.id;
  try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* ignore */ }

  setTimeout(async () => {
    if (syncTabId === tab.id) {
      const r2 = await chrome.storage.local.get('syncState');
      if (r2.syncState?.status === 'pending') {
        await chrome.storage.local.set({ syncState: { status: 'error', reason: 'timeout' } });
      }
      try { await chrome.tabs.remove(tab.id); } catch (e) { /* déjà fermé */ }
      syncTabId = null;
      // Reset tous les états en cas de timeout
      await chrome.storage.local.set({
        syncState: { status: 'idle' },
        publisherSyncState: { status: 'idle' },
        kindsSyncState: { status: 'idle' }
      });
    }
  }, 60000);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'MB_LAUNCH_SYNC') {
    launchPublisherSync().then(() => sendResponse({ ok: true }));
    return true;
  }

  // Publishers terminés → enchaîner kinds
  // Ne ferme l'onglet que si c'est bien l'onglet publishers
  if (msg?.type === 'MB_PUBLISHER_SYNC_TAB_DONE') {
    const tabId = sender.tab?.id;
    setTimeout(async () => {
      try { if (tabId && tabId === publisherTabId) await chrome.tabs.remove(tabId); } catch (e) { /* déjà fermé */ }
      if (publisherTabId === tabId) publisherTabId = null;
      launchKindsSync();
    }, 3000);
  }

  // Kinds terminés → enchaîner collection
  // Ne ferme l'onglet que si c'est bien l'onglet kinds
  if (msg?.type === 'MB_KINDS_SYNC_TAB_DONE') {
    const tabId = sender.tab?.id;
    setTimeout(async () => {
      try { if (tabId && tabId === kindsTabId) await chrome.tabs.remove(tabId); } catch (e) { /* déjà fermé */ }
      if (kindsTabId === tabId) kindsTabId = null;
      launchCollectionSync();
    }, 3000);
  }

  // Collection terminée → fin de la synchro complète
  if (msg?.type === 'MB_SYNC_TAB_DONE') {
    const tabId = sender.tab?.id;
    setTimeout(async () => {
      try { if (tabId) await chrome.tabs.remove(tabId); } catch (e) { /* déjà fermé */ }
      if (syncTabId === tabId) syncTabId = null;
      // Reset tous les états à 'idle' pour la prochaine synchro
      await chrome.storage.local.set({
        syncState: { status: 'idle' },
        publisherSyncState: { status: 'idle' },
        kindsSyncState: { status: 'idle' }
      });
    }, 3000);
  }

  // Recherche de manga sur le site Mangacollec
  if (msg?.type === 'MB_CHECK_MANGA_ON_SITE') {
    checkMangaOnSite(msg.title).then(sendResponse);
    return true; // response asynchrone
  }

  // Résultats de recherche reçus du content script (obsolète - géré directement par executeScript)
  // if (msg?.type === 'MB_SEARCH_RESULTS') {
  //   console.log('[MB-DEBUG] Résultats reçus du content script:', msg.results);
  //   if (searchResolve) {
  //     const results = msg.results || [];
  //     const response = { found: results.length > 0, results };
  //     console.log('[MB-DEBUG] Réponse envoyée au caller:', response);
  //     searchResolve(response);
  //     searchResolve = null;
  //   }
  // }
});