document.getElementById('mb-mascot-slot').innerHTML = MangaBridgeMascot.svg(40);

let activeTab = null;

function formatTime(ts) {
  if (!ts) return 'jamais';
  const d = new Date(ts);
  return d.toLocaleDateString('fr-FR') + ' à ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

async function refreshDBInfo() {
  const [db, annexDB, updatedAt] = await Promise.all([
    MangaBridgeStorage.getDB(),
    MangaBridgeStorage.getAnnexDB(),
    MangaBridgeStorage.getDBUpdatedAt()
  ]);
  const mainCount = Object.keys(db).length;
  const annexCount = Object.keys(annexDB).length;
  const total = mainCount + annexCount;
  document.getElementById('mb-db-count').innerText = `${total} entrées (${mainCount} MC + ${annexCount} annexes)`;
  document.getElementById('mb-db-time').innerText = formatTime(updatedAt);
}

async function refreshSettings() {
  const settings = await MangaBridgeStorage.getSettings();
  document.getElementById('mb-username').value = settings.mangacollecUsername || '';
  document.getElementById('mb-hide-toggle').checked = !!settings.hideOwned;
}

async function refreshSiteStatus() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tab;
  const statusEl = document.getElementById('mb-site-status');
  const hostEl = document.getElementById('mb-site-hostname');
  const actionBtn = document.getElementById('mb-site-action');
  const enableToggle = document.getElementById('mb-site-enable-toggle');

  if (!tab?.url || !/^https?:/.test(tab.url)) {
    hostEl.innerText = 'Page non compatible';
    statusEl.innerText = '';
    actionBtn.style.display = 'none';
    enableToggle.disabled = true;
    enableToggle.checked = false;
    return;
  }

  const hostname = new URL(tab.url).hostname;
  hostEl.innerText = hostname;

  const isEnabled = await MangaBridgeStorage.isSiteEnabled(hostname);
  enableToggle.disabled = false;
  enableToggle.checked = isEnabled;
  enableToggle.onchange = async () => {
    await MangaBridgeStorage.setSiteEnabled(hostname, enableToggle.checked);
    // site-injector.js réagit en direct via chrome.storage.onChanged,
    // aucun rechargement de page n'est nécessaire.
    refreshSiteStatus();
  };

  const sets = await MangaBridgeStorage.getSelectorSets(hostname);
  if (sets.length > 0) {
    statusEl.innerText = `✅ Configuré (${sets.length} set${sets.length > 1 ? 's' : ''})`;
    statusEl.className = 'ok';
    actionBtn.innerText = '🎓 Ajouter un autre set';
    actionBtn.onclick = async () => {
      await chrome.tabs.sendMessage(tab.id, { type: 'MB_START_LEARNING' });
      window.close();
    };
  } else {
    statusEl.innerText = isEnabled ? 'Activé, pas encore configuré' : 'Non configuré';
    statusEl.className = 'missing';
    actionBtn.innerText = '🎓 Configurer ce site';
    actionBtn.onclick = async () => {
      await chrome.tabs.sendMessage(tab.id, { type: 'MB_START_LEARNING' });
      window.close();
    };
  }
  actionBtn.style.display = 'block';
}

document.getElementById('mb-username').addEventListener('change', async (e) => {
  await MangaBridgeStorage.setSettings({ mangacollecUsername: e.target.value.trim() });
});

document.getElementById('mb-hide-toggle').addEventListener('change', async (e) => {
  await MangaBridgeStorage.setSettings({ hideOwned: e.target.checked });
});

document.getElementById('mb-options-btn').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById('mb-sync-btn').addEventListener('click', async () => {
  const username = document.getElementById('mb-username').value.trim();
  const statusEl = document.getElementById('mb-sync-status');
  const btn = document.getElementById('mb-sync-btn');

  if (!username) {
    statusEl.innerText = '⚠️ Renseigne d\'abord ton pseudo Mangacollec.';
    return;
  }
  await MangaBridgeStorage.setSettings({ mangacollecUsername: username });

  btn.disabled = true;
  const startTime = Date.now();
  const timeoutMs = 50000;

  chrome.runtime.sendMessage({ type: 'MB_LAUNCH_SYNC' });

  const countdown = setInterval(() => {
    const remaining = Math.max(0, Math.ceil((timeoutMs - (Date.now() - startTime)) / 1000));
    statusEl.innerText = `⏳ Synchro en cours... ${remaining}s`;
    if (remaining <= 0) clearInterval(countdown);
  }, 1000);

  const listener = (changes, area) => {
    if (area !== 'local' || !changes.syncState) return;
    const state = changes.syncState.newValue;
    if (state?.status === 'done') {
      clearInterval(countdown);
      chrome.storage.onChanged.removeListener(listener);
      statusEl.innerText = '✅ Synchro réussie !';
      btn.disabled = false;
      refreshDBInfo();
    } else if (state?.status === 'error') {
      clearInterval(countdown);
      chrome.storage.onChanged.removeListener(listener);
      statusEl.innerText = state.reason === 'missing_username'
        ? '⚠️ Pseudo manquant.'
        : '❌ Échec de la synchro (vérifie ta connexion sur Mangacollec).';
      btn.disabled = false;
    }
  };
  chrome.storage.onChanged.addListener(listener);
});

refreshDBInfo();
refreshSettings();
refreshSiteStatus();
