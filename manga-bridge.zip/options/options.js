// ==========================================
// Échappement HTML — protège contre l'injection XSS via innerHTML
// ==========================================
function escapeHtml(str) {
  if (str == null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ==========================================
// Confirmation douce (remplace confirm() natif)
// ==========================================
function confirmAction(message) {
  return new Promise((resolve) => {
    const existing = document.getElementById('mb-confirm-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'mb-confirm-overlay';
    overlay.style.cssText = `
      position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:9999;
      display:flex; align-items:center; justify-content:center;
    `;
    const box = document.createElement('div');
    box.style.cssText = `
      background:#1f1f27; color:#fff; padding:24px; border-radius:14px;
      max-width:420px; width:90%; text-align:center;
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
    `;
    // Construction DOM sécurisée (pas d'innerHTML pour le message)
    const msgP = document.createElement('p');
    msgP.style.cssText = 'margin:0 0 18px; font-size:14px;';
    msgP.textContent = message;
    box.appendChild(msgP);
    const btnsDiv = document.createElement('div');
    btnsDiv.style.cssText = 'display:flex; gap:10px; justify-content:center;';
    const btnStyle = 'padding:8px 20px; color:#fff; border:none; border-radius:8px; font-weight:600; cursor:pointer;';
    const yesBtn = document.createElement('button');
    yesBtn.id = 'mb-confirm-yes';
    yesBtn.style.cssText = btnStyle + ' background:#e74c3c;';
    yesBtn.textContent = 'Oui';
    btnsDiv.appendChild(yesBtn);
    const noBtn = document.createElement('button');
    noBtn.id = 'mb-confirm-no';
    noBtn.style.cssText = btnStyle + ' background:#555;';
    noBtn.textContent = 'Non';
    btnsDiv.appendChild(noBtn);
    box.appendChild(btnsDiv);
    overlay.appendChild(box);
    document.body.appendChild(overlay);

    const close = (result) => { overlay.remove(); resolve(result); };
    yesBtn.onclick = () => close(true);
    noBtn.onclick = () => close(false);
    overlay.onclick = (e) => { if (e.target === overlay) close(false); };
  });
}

async function renderIgnoredKeys() {
  const byHost = await MangaBridgeStorage.getAllExcludedByHost();
  const list = document.getElementById('mb-ignored-list');
  const hostnames = Object.keys(byHost);

  if (hostnames.length === 0) {
    list.innerHTML = '<p class="mb-empty">Aucun match ignoré pour le moment.</p>';
    return;
  }

  list.innerHTML = '';
  hostnames.forEach(hostname => {
    const entries = byHost[hostname];
    const pairKeys = Object.keys(entries);
    const count = pairKeys.length;

    const details = document.createElement('details');
    details.name = 'mb-ignored-accordion';
    details.className = 'mb-site-accordion';

    const summary = document.createElement('summary');
    summary.innerText = `${hostname} (${count} match${count > 1 ? 's' : ''} ignoré${count > 1 ? 's' : ''})`;
    details.appendChild(summary);

    const body = document.createElement('div');
    body.className = 'mb-site-accordion-body';

    pairKeys.forEach(pairKey => {
      const entry = entries[pairKey];
      const item = document.createElement('div');
      item.className = 'mb-profile-item';
      // Construction DOM sécurisée (pas d'innerHTML avec données storage)
      const innerDiv = document.createElement('div');
      const domainDiv = document.createElement('div');
      domainDiv.className = 'mb-profile-domain';
      domainDiv.textContent = entry.siteTitle || entry.cleanGeneric;
      const selDiv = document.createElement('div');
      selDiv.className = 'mb-profile-sel';
      selDiv.textContent = '↳ ' + (entry.dbNom || entry.dbKey);
      innerDiv.appendChild(domainDiv);
      innerDiv.appendChild(selDiv);
      item.appendChild(innerDiv);
      const delBtn = document.createElement('button');
      delBtn.className = 'mb-btn-mini';
      delBtn.innerText = "✅ Supprimer l'exclusion";
      delBtn.onclick = async () => {
        await MangaBridgeStorage.unexcludePair(hostname, pairKey);
        renderIgnoredKeys();
      };
      item.appendChild(delBtn);
      body.appendChild(item);
    });

    details.appendChild(body);
    list.appendChild(details);
  });
}

document.getElementById('mb-mascot-slot').innerHTML = MangaBridgeMascot.svg(48);

async function initPositionPicker() {
  const settings = await MangaBridgeStorage.getSettings();
  const radios = document.querySelectorAll('input[name="mb-position"]');
  radios.forEach(r => {
    r.checked = (r.value === settings.panelPosition);
    r.addEventListener('change', async () => {
      if (r.checked) await MangaBridgeStorage.setSettings({ panelPosition: r.value });
    });
  });

  const bubbleRadios = document.querySelectorAll('input[name="mb-bubble-mode"]');
  bubbleRadios.forEach(r => {
    r.checked = (r.value === (settings.bubbleMode || 'follow'));
    r.addEventListener('change', async () => {
      if (r.checked) await MangaBridgeStorage.setSettings({ bubbleMode: r.value });
    });
  });
}

function formatTime(ts) {
  if (!ts) return 'jamais';
  const d = new Date(ts);
  return d.toLocaleDateString('fr-FR') + ' à ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}

async function renderProfiles() {
  const profiles = await MangaBridgeStorage.getProfiles();
  const list = document.getElementById('mb-profiles-list');
  const domains = Object.keys(profiles);

  if (domains.length === 0) {
    list.innerHTML = '<p class="mb-empty">Aucun site configuré pour le moment.</p>';
    return;
  }

  list.innerHTML = '';
  for (const domain of domains) {
    const sets = await MangaBridgeStorage.getSelectorSets(domain);

    // <details name="..."> = accordéon natif EXCLUSIF (ouvrir un site ferme
    // automatiquement celui qui était déroulé) — pas besoin de JS pour ça.
    const details = document.createElement('details');
    details.name = 'mb-sites-accordion';
    details.className = 'mb-site-accordion';

    const summary = document.createElement('summary');
    summary.innerText = `${domain} (${sets.length} set${sets.length > 1 ? 's' : ''})`;
    details.appendChild(summary);

    const body = document.createElement('div');
    body.className = 'mb-site-accordion-body';

    sets.forEach((s, idx) => {
      const item = document.createElement('div');
      item.className = 'mb-profile-item';
      // Construction DOM sécurisée (pas d'innerHTML avec données storage)
      const innerDiv = document.createElement('div');
      const labelDiv = document.createElement('div');
      labelDiv.className = 'mb-profile-domain';
      labelDiv.textContent = s.label || 'Set ' + (idx + 1);
      const selDiv = document.createElement('div');
      selDiv.className = 'mb-profile-sel';
      selDiv.textContent = s.cardSelector + (s.titleSelector ? ' → ' + s.titleSelector : ' (case entière)');
      const concatLabel = document.createElement('label');
      concatLabel.className = 'mb-concat-toggle';
      const concatCheck = document.createElement('input');
      concatCheck.type = 'checkbox';
      concatCheck.checked = !!s.titleConcat;
      concatLabel.appendChild(concatCheck);
      concatLabel.appendChild(document.createTextNode(' Regrouper tous les éléments du titre (série + tome séparés)'));
      innerDiv.appendChild(labelDiv);
      innerDiv.appendChild(selDiv);
      innerDiv.appendChild(concatLabel);
      item.appendChild(innerDiv);
      const concatCheckbox = concatCheck;
      concatCheckbox.onchange = async () => {
        await MangaBridgeStorage.updateSelectorSet(domain, idx, { titleConcat: concatCheckbox.checked });
      };
      const delBtn = document.createElement('button');
      delBtn.className = 'mb-btn-mini';
      delBtn.innerText = '🗑️ Supprimer';
      delBtn.onclick = async () => {
        await MangaBridgeStorage.removeSelectorSet(domain, idx);
        renderProfiles();
      };
      item.appendChild(delBtn);
      body.appendChild(item);
    });

    details.appendChild(body);
    list.appendChild(details);
  }
}

async function renderDBInfo() {
  const db = await MangaBridgeStorage.getDB();
  const updatedAt = await MangaBridgeStorage.getDBUpdatedAt();
  document.getElementById('mb-db-count').innerText = `${Object.keys(db).length} entrées`;
  document.getElementById('mb-db-time').innerText = formatTime(updatedAt);
}

document.getElementById('mb-reset-db').addEventListener('click', async () => {
  if (!await confirmAction('Vider entièrement la base de correspondance Mangacollec ? Cette action est irréversible.')) return;
  await MangaBridgeStorage.setDB({});
  renderDBInfo();
});

document.getElementById('mb-reset-publishers').addEventListener('click', async () => {
  if (!await confirmAction('Vider la liste des éditeurs ? Ils seront de nouveau récupérés lors de la prochaine synchro.')) return;
  await MangaBridgeStorage.setLearnedPublishers({});
});

document.getElementById('mb-reset-genres').addEventListener('click', async () => {
  if (!await confirmAction('Vider la liste des genres ? Ils seront de nouveau récupérés lors de la prochaine synchro.')) return;
  await MangaBridgeStorage.setLearnedGenres({});
});

// ==========================================
// Onglets
// ==========================================
document.querySelectorAll('.mb-tab-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    document.querySelectorAll('.mb-tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.mb-tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('mb-tab-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'matching') await renderMatchingTab();
    if (btn.dataset.tab === 'stats') renderStats();
    if (btn.dataset.tab === 'history') renderHistory();
    if (btn.dataset.tab === 'annex') {
      annexPage = 1;
      renderAnnexList();
      await renderAnnexGenreChips();
      await renderAnnexPublisherChips();
    }
    if (btn.dataset.tab === 'backup') renderBackupTab();
    if (btn.dataset.tab === 'tutorial') {
      updateTutorialStep(tutorialCurrentStep);
      const pct = (tutorialCurrentStep / (TUTORIAL_TOTAL_STEPS - 1)) * 100;
      updateProgressBar(pct);
    }
  });
});

// ==========================================
// Statistiques (barres horizontales, sans dépendance externe)
// ==========================================
function renderStatBars(containerEl, dataObj, total) {
  const all = Object.entries(dataObj).sort((a, b) => b[1] - a[1]);
  if (all.length === 0) {
    containerEl.innerHTML = '<p class="mb-empty">Pas encore de données — lance une synchro depuis le popup.</p>';
    return;
  }

  const LIMIT = 15;
  const renderRows = (entries) => {
    const fragment = document.createDocumentFragment();
    entries.forEach(([name, count]) => {
      const pct = total > 0 ? (count / total * 100) : 0;
      const row = document.createElement('div');
      row.className = 'mb-stat-row';
      const labelsDiv = document.createElement('div');
      labelsDiv.className = 'mb-stat-labels';
      const nameSpan = document.createElement('span');
      nameSpan.textContent = name;
      const countSpan = document.createElement('span');
      countSpan.textContent = `${count} (${pct.toFixed(1)}%)`;
      labelsDiv.appendChild(nameSpan);
      labelsDiv.appendChild(countSpan);
      const trackDiv = document.createElement('div');
      trackDiv.className = 'mb-stat-bar-track';
      const fillDiv = document.createElement('div');
      fillDiv.className = 'mb-stat-bar-fill';
      fillDiv.style.width = pct + '%';
      trackDiv.appendChild(fillDiv);
      row.appendChild(labelsDiv);
      row.appendChild(trackDiv);
      fragment.appendChild(row);
    });
    return fragment;
  };

  const rowsEl = document.createElement('div');
  rowsEl.appendChild(renderRows(all.slice(0, LIMIT)));

  containerEl.innerHTML = '';
  containerEl.appendChild(rowsEl);

  if (all.length > LIMIT) {
    const btnRow = document.createElement('div');
    btnRow.style.cssText = 'display:flex; gap:6px; margin-top:8px;';

    const moreBtn = document.createElement('button');
    moreBtn.className = 'mb-btn-mini';
    moreBtn.innerText = `Voir plus (${all.length - LIMIT} de plus)`;

    const lessBtn = document.createElement('button');
    lessBtn.className = 'mb-btn-mini';
    lessBtn.innerText = 'Voir moins';
    lessBtn.style.display = 'none';

    moreBtn.onclick = () => {
      rowsEl.replaceChildren(renderRows(all));
      moreBtn.style.display = 'none';
      lessBtn.style.display = '';
    };
    lessBtn.onclick = () => {
      rowsEl.replaceChildren(renderRows(all.slice(0, LIMIT)));
      moreBtn.style.display = '';
      lessBtn.style.display = 'none';
    };

    btnRow.appendChild(moreBtn);
    btnRow.appendChild(lessBtn);
    containerEl.appendChild(btnRow);
  }
}

async function renderStats() {
  const [statsData, annexDB] = await Promise.all([
    MangaBridgeStorage.getStatsData(),
    MangaBridgeStorage.getAnnexDB()
  ]);

  // Fusionne les stats de la collection Mangacollec avec celles de la base annexe
  const mergedPublishers = { ...(statsData.publishers || {}) };
  const mergedGenres = { ...(statsData.genres || {}) };

  // Parcourt chaque entrée de la base annexe pour compter éditeurs et genres
  for (const entry of Object.values(annexDB)) {
    if (entry.publisher) {
      const pub = entry.publisher;
      mergedPublishers[pub] = (mergedPublishers[pub] || 0) + 1;
    }
    if (Array.isArray(entry.genres)) {
      for (const genre of entry.genres) {
        mergedGenres[genre] = (mergedGenres[genre] || 0) + 1;
      }
    }
  }

  const totalPub = Object.values(mergedPublishers).reduce((a, b) => a + b, 0);
  const totalGen = Object.values(mergedGenres).reduce((a, b) => a + b, 0);
  renderStatBars(document.getElementById('mb-stats-publishers'), mergedPublishers, totalPub);
  renderStatBars(document.getElementById('mb-stats-genres'), mergedGenres, totalGen);
}

// ==========================================
// Historique (recherche + pagination numérotée)
// ==========================================
const HISTORY_PAGE_SIZE = 50;
let historyItemsCache = [];
let historyPage = 1;

// Pagination base annexes
let annexPage = 1;
const ANNEX_PER_PAGE = 10;

async function renderHistory() {
  historyItemsCache = await MangaBridgeStorage.getHistoryItems();
  historyPage = 1;
  renderHistoryList();
}

function buildPageList(current, total) {
  const radius = 3; // pages affichées de chaque côté de la page courante
  if (total <= 1) return [1];

  const pages = new Set([1, total]);
  for (let p = current - radius; p <= current + radius; p++) {
    if (p >= 1 && p <= total) pages.add(p);
  }
  const sorted = [...pages].sort((a, b) => a - b);

  const result = [];
  for (let i = 0; i < sorted.length; i++) {
    if (i > 0 && sorted[i] - sorted[i - 1] > 1) result.push('…');
    result.push(sorted[i]);
  }
  return result;
}

function renderHistoryList() {
  const search = (document.getElementById('mb-history-search').value || '').toLowerCase();
  const filtered = historyItemsCache.filter(i =>
    i.title.toLowerCase().includes(search) || i.pub.toLowerCase().includes(search)
  );
  const totalPages = Math.max(1, Math.ceil(filtered.length / HISTORY_PAGE_SIZE));
  if (historyPage > totalPages) historyPage = totalPages;
  const visible = filtered.slice((historyPage - 1) * HISTORY_PAGE_SIZE, historyPage * HISTORY_PAGE_SIZE);

  const list = document.getElementById('mb-history-list');
  if (visible.length === 0) {
    list.innerHTML = '<p class="mb-empty">Aucun résultat.</p>';
  } else {
    // Construction DOM sécurisée (pas d'innerHTML avec données storage)
    list.innerHTML = '';
    visible.forEach(i => {
      const item = document.createElement('div');
      item.className = 'mb-history-item';
      const leftDiv = document.createElement('div');
      const titleB = document.createElement('b');
      titleB.textContent = i.title;
      const pubSmall = document.createElement('small');
      pubSmall.textContent = `(${i.pub})`;
      const br = document.createElement('br');
      const subtitleSmall = document.createElement('small');
      subtitleSmall.style.color = 'var(--accent)';
      subtitleSmall.textContent = i.subTitle;
      leftDiv.appendChild(titleB);
      leftDiv.appendChild(pubSmall);
      leftDiv.appendChild(br);
      leftDiv.appendChild(subtitleSmall);
      const rightDiv = document.createElement('div');
      const dateSmall = document.createElement('small');
      dateSmall.textContent = i.dateStr;
      rightDiv.appendChild(dateSmall);
      item.appendChild(leftDiv);
      item.appendChild(rightDiv);
      list.appendChild(item);
    });
  }

  document.getElementById('mb-history-page-info').innerText = `${filtered.length} résultat${filtered.length > 1 ? 's' : ''}`;

  const pagesEl = document.getElementById('mb-history-pages');
  pagesEl.innerHTML = '';

  const goTo = (p) => {
    historyPage = Math.max(1, Math.min(p, totalPages));
    renderHistoryList();
    document.getElementById('mb-history-list').scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const navBtn = (txt, target, title, disabled) => {
    const b = document.createElement('button');
    b.innerText = txt;
    b.className = 'mb-page-btn mb-page-nav';
    b.title = title;
    b.disabled = disabled;
    b.onclick = () => goTo(target);
    return b;
  };

  pagesEl.appendChild(navBtn('‹', historyPage - 1, 'Page précédente', historyPage <= 1));

  buildPageList(historyPage, totalPages).forEach(p => {
    if (p === '…') {
      const dots = document.createElement('span');
      dots.innerText = '…';
      dots.style.cssText = 'color:var(--text-muted); padding:0 4px;';
      pagesEl.appendChild(dots);
      return;
    }
    const btn = document.createElement('button');
    btn.innerText = p;
    btn.className = 'mb-page-btn' + (p === historyPage ? ' active' : '');
    btn.onclick = () => goTo(p);
    pagesEl.appendChild(btn);
  });

  pagesEl.appendChild(navBtn('›', historyPage + 1, 'Page suivante', historyPage >= totalPages));
}

document.getElementById('mb-history-search').addEventListener('input', () => {
  historyPage = 1;
  renderHistoryList();
});

// ==========================================
// Onglet Matching
// ==========================================
// Mots-clés statiques déjà retirés par défaut dans matcher.js (mentions
// d'édition/état) — recopiés ici uniquement pour affichage, ne PAS modifier
// l'algorithme depuis cette liste.
const MB_STATIC_DEFAULT_NOISE_WORDS = [
  'collector', 'deluxe', 'perfect', 'ultimate', 'double', 'integrale',
  'speciale', 'occasion', 'neuf', 'livre', 'manga', 'poster', 'en cours'
];

async function renderDefaultNoiseList() {
  const el = document.getElementById('mb-noise-default-list');
  const learnedGenres = await MangaBridgeStorage.getLearnedGenres();
  const genreWords = learnedGenres ? Object.values(learnedGenres) : [];
  const all = [...MB_STATIC_DEFAULT_NOISE_WORDS, ...genreWords];
  el.innerHTML = '';
  all.forEach(w => {
    const span = document.createElement('span');
    span.className = 'mb-noise-chip default';
    span.textContent = w;
    el.appendChild(span);
  });
}

async function renderCustomNoiseList() {
  const words = await MangaBridgeStorage.getCustomNoiseWords();
  const el = document.getElementById('mb-noise-custom-list');
  if (words.length === 0) {
    el.innerHTML = '<p class="mb-empty">Aucun mot ajouté pour le moment.</p>';
    return;
  }
  el.innerHTML = '';
  words.forEach((word, idx) => {
    const chip = document.createElement('span');
    chip.className = 'mb-noise-chip custom';
    const textNode = document.createTextNode(word);
    chip.appendChild(textNode);
    const btn = document.createElement('button');
    btn.title = 'Retirer';
    btn.textContent = '✕';
    chip.querySelector('button').onclick = async () => {
      const current = await MangaBridgeStorage.getCustomNoiseWords();
      current.splice(idx, 1);
      await MangaBridgeStorage.setCustomNoiseWords(current);
      renderCustomNoiseList();
    };
    el.appendChild(chip);
  });
}

async function renderMatchingTab() {
  await renderDefaultNoiseList();
  await renderCustomNoiseList();
}

document.getElementById('mb-noise-add-btn').addEventListener('click', async () => {
  const statusEl = document.getElementById('mb-noise-status');
  const raw = document.getElementById('mb-noise-input').value;
  const newWords = raw.split(/[\n,]/).map(w => w.trim()).filter(w => w.length > 1);

  if (newWords.length === 0) {
    statusEl.innerText = '⚠️ Ajoute au moins un mot (2 caractères minimum).';
    return;
  }

  const current = await MangaBridgeStorage.getCustomNoiseWords();
  const merged = [...new Set([...current, ...newWords.map(w => w.toLowerCase())])];
  await MangaBridgeStorage.setCustomNoiseWords(merged);

  document.getElementById('mb-noise-input').value = '';
  statusEl.innerText = `✅ ${newWords.length} mot(s) ajouté(s).`;
  renderCustomNoiseList();
});

renderProfiles();
renderDBInfo();
renderIgnoredKeys();
initPositionPicker();

// ==========================================
// Base annexes
// ==========================================
async function renderAnnexList(search) {
  const annexDB = await MangaBridgeStorage.getAnnexDB();
  const list = document.getElementById('mb-annex-list');
  const keys = Object.keys(annexDB);

  if (keys.length === 0) {
    list.innerHTML = '<p class="mb-empty">Aucun manga dans la base annexes. Ajoute-en un avec le formulaire ci-dessus.</p>';
    document.getElementById('mb-annex-page-info').innerText = '0 résultat';
    document.getElementById('mb-annex-pages').innerHTML = '';
    return;
  }

  const filtered = search
    ? keys.filter(k => annexDB[k].nom?.toLowerCase().includes(search.toLowerCase()))
    : keys;

  if (filtered.length === 0) {
    list.innerHTML = '<p class="mb-empty">Aucun résultat.</p>';
    document.getElementById('mb-annex-page-info').innerText = '0 résultat';
    document.getElementById('mb-annex-pages').innerHTML = '';
    return;
  }

  // Pagination
  const totalPages = Math.max(1, Math.ceil(filtered.length / ANNEX_PER_PAGE));
  if (annexPage > totalPages) annexPage = totalPages;
  const visible = filtered.slice((annexPage - 1) * ANNEX_PER_PAGE, annexPage * ANNEX_PER_PAGE);

  list.innerHTML = '';
  visible.forEach(key => {
    const entry = annexDB[key];
    const item = document.createElement('div');
    item.className = 'mb-annex-item';

    const details = [];
    if (entry.publisher) details.push(`Ed: ${entry.publisher}`);
    if (entry.edition) details.push(`[${entry.edition}]`);
    if (entry.ratio) details.push(`Tomes: ${entry.ratio}`);
    if (entry.genres?.length) details.push(`Genres: ${entry.genres.join(', ')}`);

    const infoDiv = document.createElement('div');
    infoDiv.className = 'mb-annex-item-info';
    const nomDiv = document.createElement('div');
    nomDiv.className = 'mb-annex-item-nom';
    nomDiv.textContent = entry.nom;
    infoDiv.appendChild(nomDiv);
    if (details.length) {
      const detDiv = document.createElement('div');
      detDiv.className = 'mb-annex-item-details';
      detDiv.textContent = details.join(' • ');
      infoDiv.appendChild(detDiv);
    }
    item.appendChild(infoDiv);

    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'mb-annex-item-actions';
    const makeBtn = (cls, text, dataKey) => {
      const b = document.createElement('button');
      b.className = cls;
      b.textContent = text;
      b.dataset.key = dataKey;
      return b;
    };
    actionsDiv.appendChild(makeBtn('mb-btn-mini mb-annex-edit-btn', '✏️ Modifier', key));
    const checkBtn = makeBtn('mb-btn-mini mb-annex-check-btn', '🔄 Vérifier', key);
    checkBtn.title = 'Vérifier sur Mangacollec';
    actionsDiv.appendChild(checkBtn);
    actionsDiv.appendChild(makeBtn('mb-btn-mini mb-btn-danger mb-annex-delete-btn', '🗑️', key));
    item.appendChild(actionsDiv);
    list.appendChild(item);
  });

  // Info pagination
  document.getElementById('mb-annex-page-info').innerText = `${filtered.length} résultat${filtered.length > 1 ? 's' : ''}`;

  // Build pagination buttons
  const pagesEl = document.getElementById('mb-annex-pages');
  pagesEl.innerHTML = '';

  const goTo = (p) => {
    annexPage = Math.max(1, Math.min(p, totalPages));
    renderAnnexList(search);
    list.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const navBtn = (txt, target, title, disabled) => {
    const b = document.createElement('button');
    b.innerText = txt;
    b.className = 'mb-page-btn mb-page-nav';
    b.title = title;
    b.disabled = disabled;
    b.onclick = () => goTo(target);
    return b;
  };

  pagesEl.appendChild(navBtn('‹', annexPage - 1, 'Page précédente', annexPage <= 1));

  buildPageList(annexPage, totalPages).forEach(p => {
    if (p === '…') {
      const dots = document.createElement('span');
      dots.innerText = '…';
      dots.style.cssText = 'color:var(--text-muted); padding:0 4px;';
      pagesEl.appendChild(dots);
      return;
    }
    const btn = document.createElement('button');
    btn.innerText = p;
    btn.className = 'mb-page-btn' + (p === annexPage ? ' active' : '');
    btn.onclick = () => goTo(p);
    pagesEl.appendChild(btn);
  });

  pagesEl.appendChild(navBtn('›', annexPage + 1, 'Page suivante', annexPage >= totalPages));

  // Bind delete buttons
  list.querySelectorAll('.mb-annex-delete-btn').forEach(btn => {
    btn.onclick = async () => {
      if (!await confirmAction(`Supprimer "${annexDB[btn.dataset.key]?.nom}" de la base annexes ?`)) return;
      await MangaBridgeStorage.deleteAnnexEntry(btn.dataset.key);
      annexPage = 1;
      renderAnnexList();
    };
  });

  // Bind edit buttons
  list.querySelectorAll('.mb-annex-edit-btn').forEach(btn => {
    btn.onclick = async () => {
      editingAnnexKey = btn.dataset.key;
      document.getElementById('mb-annex-add-btn').innerText = '💾 Modifier';
      const entry = annexDB[btn.dataset.key];
      document.getElementById('mb-annex-nom').value = entry.nom || '';
      selectedAnnexPublisher = entry.publisher || '';
      document.getElementById('mb-annex-edition').value = entry.edition || '';
      document.getElementById('mb-annex-tomes').value = entry.tomes?.join(', ') || '';
      document.getElementById('mb-annex-total').value = entry.ratio?.split('/')[1] || '';
      // Pré-sélectionner les genres de l'entrée
      selectedAnnexGenres = new Set(entry.genres || []);
      await renderAnnexGenreChips();
      // Scroll to form
      document.getElementById('mb-annex-nom').scrollIntoView({ behavior: 'smooth' });
    };
  });

  // Bind check buttons (vérifier sur Mangacollec si l'entrée a été ajoutée entre-temps)
  list.querySelectorAll('.mb-annex-check-btn').forEach(btn => {
    btn.onclick = async () => {
      const key = btn.dataset.key;
      const entry = annexDB[key];
      if (!entry) return;

      const statusEl = document.getElementById('mb-annex-status');
      statusEl.innerText = `⏳ Vérification de "${entry.nom}" sur Mangacollec...`;

      const result = await checkMangaOnMangacollec(entry.nom);

      if (result.found) {
        if (result.location === 'Site Mangacollec' && result.bestScore != null) {
          statusEl.innerText = `⚠️ "${entry.nom}" existe maintenant sur MangaCollec (match ${result.bestScore}% → "${result.bestTitle}"). Vous pouvez le supprimer de la base annexes.`;
        } else {
          statusEl.innerText = `⚠️ "${entry.nom}" existe déjà dans ${result.location || 'Mangacollec'}. Vous pouvez le supprimer de la base annexes.`;
        }
      } else {
        statusEl.innerText = `✅ "${entry.nom}" toujours absent de Mangacollec, reste utile en base annexes.`;
      }
    };
  });
}

// ==========================================
// Gestion des genres pour la base annexe
// ==========================================
let selectedAnnexGenres = new Set();

async function renderAnnexGenreChips(filter = '') {
  const container = document.getElementById('mb-annex-genres-container');
  const learnedGenres = await MangaBridgeStorage.getLearnedGenres();
  const genreNames = learnedGenres ? Object.values(learnedGenres) : [];
  
  const filtered = filter 
    ? genreNames.filter(g => g.toLowerCase().includes(filter.toLowerCase()))
    : genreNames;
  
  container.innerHTML = '';
  
  if (filtered.length === 0) {
    container.innerHTML = '<p class="mb-empty">Aucun genre trouvé.</p>';
    return;
  }
  
  filtered.forEach(genreName => {
    const chip = document.createElement('span');
    chip.className = 'mb-annex-genre-chip';
    if (selectedAnnexGenres.has(genreName)) {
      chip.classList.add('mb-annex-genre-chip-selected');
    }
    chip.textContent = genreName;
    chip.onclick = async () => {
      if (selectedAnnexGenres.has(genreName)) {
        selectedAnnexGenres.delete(genreName);
      } else {
        selectedAnnexGenres.add(genreName);
      }
      renderAnnexGenreChips(document.getElementById('mb-annex-genres-search').value);
    };
    container.appendChild(chip);
  });
}

document.getElementById('mb-annex-genres-search').addEventListener('input', async (e) => {
  renderAnnexGenreChips(e.target.value);
});

// ==========================================
// Gestion des éditeurs pour la base annexe
// ==========================================
let selectedAnnexPublisher = '';
let editingAnnexKey = null; // clé de l'entrée en cours d'édition

async function renderAnnexPublisherChips(filter = '') {
  const container = document.getElementById('mb-annex-publishers-container');
  const learnedPublishers = await MangaBridgeStorage.getLearnedPublishers();
  const publisherNames = Object.values(learnedPublishers);
  
  const filtered = filter 
    ? publisherNames.filter(p => p.toLowerCase().includes(filter.toLowerCase()))
    : publisherNames;
  
  container.innerHTML = '';
  
  if (filtered.length === 0) {
    container.innerHTML = '<p class="mb-empty">Aucun éditeur trouvé. Lance une synchro pour récupérer la liste.</p>';
    return;
  }
  
  filtered.forEach(publisherName => {
    const chip = document.createElement('span');
    chip.className = 'mb-annex-genre-chip';
    if (selectedAnnexPublisher === publisherName) {
      chip.classList.add('mb-annex-genre-chip-selected');
    }
    chip.textContent = publisherName;
    chip.onclick = () => {
      if (selectedAnnexPublisher === publisherName) {
        selectedAnnexPublisher = '';
      } else {
        selectedAnnexPublisher = publisherName;
      }
      renderAnnexPublisherChips(document.getElementById('mb-annex-publisher-search').value);
    };
    container.appendChild(chip);
  });
}

document.getElementById('mb-annex-publisher-search').addEventListener('input', (e) => {
  renderAnnexPublisherChips(e.target.value);
});

// Vérifie si un titre existe sur Mangacollec (sans vérifier la base annexe)
// Utilisé par le bouton "Vérifier" pour savoir si une entrée de la base annexes
// a été ajoutée sur Mangacollec entre-temps.
// Vérifie : 1. Base sync Mangacollec  3. Site Mangacollec
// Retourne { found: true, location: "Base Mangacollec" | "Site Mangacollec" } ou { found: false }
async function checkMangaOnMangacollec(title) {
  const THRESHOLD = 0.85;
  
  if (!title || title.length < 3) {
    console.warn(`Titre trop court pour vérification: "${title}"`);
    return { found: false };
  }
  
  // Étape 1 : Base sync Mangacollec locale
  try {
    const db = await MangaBridgeStorage.getDB();
    if (Object.keys(db).length > 0) {
      MatchingEngine.initialize(db, {}, {});
      const best = MatchingEngine.findBestMatch(title);
      console.log(`Check Mangacollec (base sync): "${title}" -> score=${best.score.toFixed(2)}`);
      if (best.score >= THRESHOLD) {
        console.log(`  ✅ Trouvé dans base sync: "${db[best.key]?.nom}"`);
        return { found: true, location: 'Base Mangacollec' };
      }
    }
  } catch (e) {
    console.warn('Erreur vérification base sync:', e);
  }
  
  // Étape 3 : Recherche sur le site Mangacollec (sans étape 2 base annexe)
  try {
    console.log(`Check Mangacollec (site): "${title}" -> recherche en cours...`);
    const searchResult = await chrome.runtime.sendMessage({
      type: 'MB_CHECK_MANGA_ON_SITE',
      title: title
    });
    
    if (searchResult && searchResult.found) {
      const bestScore = Math.round(searchResult.bestScore * 100);
      console.log(`  ✅ Trouvé sur le site Mangacollec: meilleur match ${bestScore}% → ${searchResult.results?.[0]?.title || 'N/A'}`);
      return { found: true, location: 'Site Mangacollec', bestScore, bestTitle: searchResult.results?.[0]?.title };
    }
    
    if (searchResult && searchResult.error === 'timeout') {
      console.warn('Timeout recherche sur Mangacollec -> on considère non trouvé');
    }
  } catch (e) {
    console.warn('Erreur vérification site Mangacollec:', e);
  }
  
  console.log(`"${title}" non trouvé sur Mangacollec`);
  return { found: false };
}

// Vérifie si un titre existe déjà, dans l'ordre :
// 1. Base sync Mangacollec locale (mangaBridgeDB)
// 2. Base annexe locale (annexDB)
// 3. Site Mangacollec via recherche web
// Retourne { found: true, location: "Base Mangacollec" | "Base annexes" | "Site Mangacollec" } ou { found: false }
async function checkMangaExistsEverywhere(title) {
  const THRESHOLD = 0.85;
  
  if (!title || title.length < 3) {
    console.warn(`Titre trop court pour vérification: "${title}"`);
    return { found: false };
  }
  
  // Étape 1 : Base sync Mangacollec locale
  try {
    const db = await MangaBridgeStorage.getDB();
    if (Object.keys(db).length > 0) {
      MatchingEngine.initialize(db, {}, {});
      const best = MatchingEngine.findBestMatch(title);
      console.log(`Check étape 1 (base sync): "${title}" -> score=${best.score.toFixed(2)}`);
      if (best.score >= THRESHOLD) {
        console.log(`  ✅ Trouvé dans base sync: "${db[best.key]?.nom}"`);
        return { found: true, location: 'Base Mangacollec' };
      }
    }
  } catch (e) {
    console.warn('Erreur vérification base sync:', e);
  }
  
  // Étape 2 : Base annexe locale
  try {
    const annexDB = await MangaBridgeStorage.getAnnexDB();
    if (Object.keys(annexDB).length > 0) {
      MatchingEngine.initialize(annexDB, {}, {});
      const best = MatchingEngine.findBestMatch(title);
      console.log(`Check étape 2 (base annexe): "${title}" -> score=${best.score.toFixed(2)}`);
      if (best.score >= THRESHOLD) {
        console.log(`  ✅ Trouvé dans base annexe: "${annexDB[best.key]?.nom}"`);
        return { found: true, location: 'Base annexes' };
      }
    }
  } catch (e) {
    console.warn('Erreur vérification base annexe:', e);
  }
  
  // Étape 3 : Recherche sur le site Mangacollec
  try {
    console.log(`Check étape 3 (site Mangacollec): "${title}" -> recherche en cours...`);
    const searchResult = await chrome.runtime.sendMessage({
      type: 'MB_CHECK_MANGA_ON_SITE',
      title: title
    });
    
    if (searchResult && searchResult.found) {
      const bestScore = Math.round(searchResult.bestScore * 100);
      console.log(`  ✅ Trouvé sur le site Mangacollec: meilleur match ${bestScore}% → ${searchResult.results?.[0]?.title || 'N/A'}`);
      return { found: true, location: 'Site Mangacollec', bestScore, bestTitle: searchResult.results?.[0]?.title };
    }
    
    if (searchResult && searchResult.error === 'timeout') {
      console.warn('Timeout recherche sur Mangacollec -> on autorise l\'ajout');
    }
  } catch (e) {
    console.warn('Erreur vérification site Mangacollec:', e);
  }
  
  console.log(`"${title}" non trouvé -> peut être ajouté`);
  return { found: false };
}

document.getElementById('mb-annex-add-btn').addEventListener('click', async () => {
  const statusEl = document.getElementById('mb-annex-status');
  const nom = document.getElementById('mb-annex-nom').value.trim();

  if (!nom) {
    statusEl.innerText = '⚠️ Le titre est obligatoire.';
    return;
  }

  const tomesRaw = document.getElementById('mb-annex-tomes').value.trim();
  const tomes = tomesRaw ? tomesRaw.split(',').map(t => t.trim()).filter(Boolean) : [];
  const total = document.getElementById('mb-annex-total').value;
  const ratio = tomes.length > 0 && total ? `${tomes.length}/${total}` : (tomes.length > 0 ? `${tomes.length}/?` : '0/0');

  const genres = Array.from(selectedAnnexGenres);

  const entry = {
    nom,
    publisher: selectedAnnexPublisher || undefined,
    edition: document.getElementById('mb-annex-edition').value.trim() || undefined,
    tomes,
    ratio,
    genres: genres.length ? genres : undefined
  };

  // Mode édition : on met à jour sans vérification
  if (editingAnnexKey) {
    await MangaBridgeStorage.updateAnnexEntry(editingAnnexKey, entry);
    editingAnnexKey = null;
    document.getElementById('mb-annex-add-btn').innerText = '➕ Ajouter';
    // Clear form
    document.getElementById('mb-annex-nom').value = '';
    selectedAnnexPublisher = '';
    document.getElementById('mb-annex-edition').value = 'Standard';
    document.getElementById('mb-annex-tomes').value = '';
    document.getElementById('mb-annex-total').value = '';
    selectedAnnexGenres.clear();
    await renderAnnexGenreChips();
    statusEl.innerText = `✅ "${nom}" modifié dans la base annexes.`;
    annexPage = 1;
    renderAnnexList();
    return;
  }

  // Mode ajout : vérification avant ajout : base sync -> base annexe -> site Mangacollec
  statusEl.innerText = '⏳ Vérification en cours...';
  const result = await checkMangaExistsEverywhere(nom);
  if (result.found) {
    const loc = result.location || 'Mangacollec';
    if (loc === 'Site Mangacollec' && result.bestScore != null) {
      statusEl.innerText = `⚠️ "${nom}" existe déjà sur MangaCollec (match ${result.bestScore}% → "${result.bestTitle}"). Pas besoin de l'ajouter en base annexes.`;
    } else {
      statusEl.innerText = `⚠️ "${nom}" existe déjà dans ${loc}. Pas besoin de l'ajouter en base annexes.`;
    }
    return;
  }

  await MangaBridgeStorage.addAnnexEntry(entry);

  // Clear form
  document.getElementById('mb-annex-nom').value = '';
  selectedAnnexPublisher = '';
  document.getElementById('mb-annex-edition').value = 'Standard';
  document.getElementById('mb-annex-tomes').value = '';
  document.getElementById('mb-annex-total').value = '';
  selectedAnnexGenres.clear();
  await renderAnnexGenreChips();

  statusEl.innerText = `✅ "${nom}" ajouté à la base annexes.`;
  annexPage = 1;
  renderAnnexList();
});

document.getElementById('mb-annex-search').addEventListener('input', (e) => {
  annexPage = 1;
  renderAnnexList(e.target.value);
});

// ==========================================
// Sauvegarde / Restauration
// ==========================================
function renderBackupTab() {
  Promise.all([
    MangaBridgeStorage.getDB(),
    MangaBridgeStorage.getAnnexDB()
  ]).then(([db, annexDB]) => {
    const totalEntries = Object.keys(db).length + Object.keys(annexDB).length;
    const infoFull = document.getElementById('mb-export-full-status');
    const infoLight = document.getElementById('mb-export-light-status');
    if (infoFull) {
      infoFull.innerText = `📊 ${totalEntries} entrées au total (${Object.keys(db).length} Mangacollec + ${Object.keys(annexDB).length} annexes).`;
    }
    if (infoLight) {
      infoLight.innerText = `📊 ${Object.keys(annexDB).length} entrée(s) annexe(s) + paramètres, profils de sites, mots ignorés...`;
    }
  });
}

// Helper pour télécharger un JSON
function downloadJSON(data, filename) {
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// Export Full
document.getElementById('mb-export-full-btn').addEventListener('click', async () => {
  const statusEl = document.getElementById('mb-export-full-status');
  try {
    const state = await MangaBridgeStorage.exportFullState();
    downloadJSON(state, `manga-bridge-full-${new Date().toISOString().slice(0,10)}.json`);
    statusEl.innerText = '✅ Export full terminé ! Le fichier JSON a été téléchargé.';
  } catch (e) {
    statusEl.innerText = `❌ Erreur lors de l'export : ${e.message}`;
  }
});

// Export Light
document.getElementById('mb-export-light-btn').addEventListener('click', async () => {
  const statusEl = document.getElementById('mb-export-light-status');
  try {
    const state = await MangaBridgeStorage.exportLightState();
    downloadJSON(state, `manga-bridge-light-${new Date().toISOString().slice(0,10)}.json`);
    statusEl.innerText = '✅ Export light terminé ! Le fichier JSON a été téléchargé.';
  } catch (e) {
    statusEl.innerText = `❌ Erreur lors de l'export : ${e.message}`;
  }
});

// ==========================================
// Import unique — détecte automatiquement Full ou Light
// ==========================================
const importFileInput = document.getElementById('mb-import-file');
const importBtn = document.getElementById('mb-import-btn');
const importStatusEl = document.getElementById('mb-import-status');

// Active/désactive le bouton selon la validité du fichier sélectionné
importFileInput.addEventListener('change', async () => {
  importBtn.disabled = true;
  importStatusEl.innerText = '';

  if (!importFileInput.files.length) {
    importBtn.disabled = true;
    return;
  }

  try {
    const text = await importFileInput.files[0].text();
    const data = JSON.parse(text);

    // Vérifie que le fichier vient bien de Manga-Bridge
    if (data._mangaBridgeBackup !== true) {
      importBtn.disabled = true;
      importStatusEl.innerText = '❌ Ce fichier n\'est pas un backup Manga-Bridge valide.';
      return;
    }

    // Détecter le type : présence de mangaBridgeDB = Full, sinon Light
    const isFull = !!data.mangaBridgeDB;
    const typeLabel = isFull ? 'sauvegarde complète (Full)' : 'sauvegarde light (Light)';

    importBtn.disabled = false;
    importStatusEl.innerText = `✅ Fichier Manga-Bridge valide détecté : ${typeLabel}. Tu peux cliquer sur Importer.`;
  } catch (e) {
    importBtn.disabled = true;
    importStatusEl.innerText = '❌ Le fichier n\'est pas un JSON valide.';
  }
});

importBtn.addEventListener('click', async () => {
  if (!importFileInput.files.length) {
    importStatusEl.innerText = '⚠️ Sélectionne un fichier JSON.';
    return;
  }

  try {
    const text = await importFileInput.files[0].text();
    const data = JSON.parse(text);

    // Détecter le type
    const isFull = !!data.mangaBridgeDB;

    if (isFull) {
      // Confirmation douce (confirm() bloquant remplacé par un statut + délai)
      importStatusEl.innerText = '⚠️ Sauvegarde complète détectée. L\'import va remplacer TOUTES les données. Clique à nouveau pour confirmer.';
      importBtn.dataset.pendingImport = 'full';
      importBtn.style.background = '#e74c3c';
      importBtn.innerText = '🔴 Confirmer le remplacement total';
      // Attendre un 2ème clic avant de procéder
      const confirmHandler = async () => {
        importBtn.removeEventListener('click', confirmHandler);
        importBtn.dataset.pendingImport = '';
        importBtn.style.background = '';
        importBtn.innerText = '📥 Importer';

        const ok = await MangaBridgeStorage.importFullState(data);
        if (ok) {
          importStatusEl.innerText = '✅ Import full terminé ! Actualisation des données…';
          await refreshOptionsAfterImport();
        } else {
          importStatusEl.innerText = '❌ Le fichier n\'est pas un backup valide.';
        }
      };
      importBtn.addEventListener('click', confirmHandler);
      return;
    } else {
      const ok = await MangaBridgeStorage.importLightState(data);
      if (ok) {
        importStatusEl.innerText = '✅ Import light terminé ! Actualisation des données…';
        await refreshOptionsAfterImport();
      } else {
        importStatusEl.innerText = '❌ Le fichier n\'est pas un backup light valide.';
      }
    }
  } catch (e) {
    importStatusEl.innerText = `❌ Erreur lors de l'import : ${e.message}`;
  }
});

// ==========================================
// Actualisation douce après import (remplace location.reload())
// ==========================================
async function refreshOptionsAfterImport() {
  try {
    await renderProfiles();
    renderDBInfo();
    renderIgnoredKeys();
    await renderAnnexGenreChips();
    await renderAnnexPublisherChips();
    // Re-render le tab actif si nécessaire
    const activeTab = document.querySelector('[data-tab].mb-tab-active');
    if (activeTab) {
      const tab = activeTab.dataset.tab;
      if (tab === 'matching') await renderMatchingTab();
      if (tab === 'stats') renderStats();
      if (tab === 'history') renderHistory();
      if (tab === 'backup') renderBackupTab();
    }
  } catch (e) {
    console.error('Erreur lors de l\'actualisation après import:', e);
  }
}

// ==========================================
// Tutoriel — navigation par étapes
// ==========================================
const TUTORIAL_TOTAL_STEPS = 8; // 0 à 7
let tutorialCurrentStep = 0;

function updateTutorialStep(step) {
  tutorialCurrentStep = step;

  // Masquer toutes les étapes, afficher la bonne
  document.querySelectorAll('.mb-tutorial-step').forEach(el => {
    el.classList.toggle('active', parseInt(el.dataset.step) === step);
  });

  // Barre de progression
  const pct = (step / (TUTORIAL_TOTAL_STEPS - 1)) * 100;
  updateProgressBar(pct);

  const progressText = document.getElementById('mb-tutorial-progress-text');
  if (progressText) progressText.innerText = `Étape ${step + 1} / ${TUTORIAL_TOTAL_STEPS}`;

  // Boutons navigation
  const prevBtn = document.getElementById('mb-tutorial-prev');
  const nextBtn = document.getElementById('mb-tutorial-next');
  const doneBtn = document.getElementById('mb-tutorial-done');
  if (prevBtn) prevBtn.disabled = step === 0;
  // Sur la dernière étape, on affiche "Retour à l'accueil" à la place de "Suivant"
  const isLastStep = step === TUTORIAL_TOTAL_STEPS - 1;
  if (nextBtn) nextBtn.style.display = isLastStep ? 'none' : '';
  if (doneBtn) doneBtn.style.display = isLastStep ? '' : 'none';

  // Scroll en haut du panel
  const panel = document.getElementById('mb-tab-tutorial');
  if (panel) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Mise à jour de la barre de progression via CSS custom property
function updateProgressBar(pct) {
  const bar = document.getElementById('mb-tutorial-progress-bar');
  if (!bar) return;
  // On injecte un <style> temporaire car on ne peut pas styler ::after directement en JS
  let styleEl = document.getElementById('mb-tutorial-progress-style');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'mb-tutorial-progress-style';
    document.head.appendChild(styleEl);
  }
  styleEl.innerText = `#mb-tutorial-progress-bar::after { width: ${pct}%; }`;
}

// Boutons Précédent / Suivant
document.addEventListener('DOMContentLoaded', () => {
  const prevBtn = document.getElementById('mb-tutorial-prev');
  const nextBtn = document.getElementById('mb-tutorial-next');

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      if (tutorialCurrentStep > 0) updateTutorialStep(tutorialCurrentStep - 1);
    });
  }
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      if (tutorialCurrentStep < TUTORIAL_TOTAL_STEPS - 1) updateTutorialStep(tutorialCurrentStep + 1);
    });
  }

  // Bouton "Retour à l'accueil" (visible sur la dernière étape)
  const doneBtn = document.getElementById('mb-tutorial-done');
  if (doneBtn) {
    doneBtn.addEventListener('click', () => {
      document.querySelector('[data-tab="general"]').click();
    });
  }

  // Bouton dismiss (ne plus afficher)
  const dismissBtn = document.getElementById('mb-tutorial-dismiss');
  if (dismissBtn) {
    dismissBtn.addEventListener('click', async () => {
      await MangaBridgeStorage.setSettings({ tutorialShown: true, tutorialVisible: false });
      // Cacher l'onglet Tutoriel de la navigation
      hideTutorialTab();
      // Revenir à l'onglet général
      document.querySelector('[data-tab="general"]').click();
    });
  }

  // Bouton restart
  const restartBtn = document.getElementById('mb-tutorial-restart');
  if (restartBtn) {
    restartBtn.addEventListener('click', () => {
      updateTutorialStep(0);
    });
  }

  // Bouton "Réafficher le tutoriel" dans l'onglet Général
  const showBtn = document.getElementById('mb-show-tutorial-btn');
  if (showBtn) {
    showBtn.addEventListener('click', async () => {
      await MangaBridgeStorage.setSettings({ tutorialVisible: true });
      // Réafficher l'onglet s'il était caché
      const tabBtn = document.querySelector('[data-tab="tutorial"]');
      if (tabBtn) tabBtn.style.display = '';
      // Basculer sur l'onglet tutoriel
      tabBtn.click();
    });
  }
});

// ==========================================
// Initialisation au chargement
// ==========================================
// Doit être APRES toutes les définitions de fonctions et variables
renderAnnexGenreChips();
renderAnnexPublisherChips();

// Masque le bouton de l'onglet Tutoriel après sa fermeture définitive.
// L'onglet reste accessible via le bouton "Rappel du tutoriel" du popup.
function hideTutorialTab() {
  const tabBtn = document.querySelector('[data-tab="tutorial"]');
  if (tabBtn) tabBtn.style.display = 'none';
}

// Détection première utilisation : si tutorialShown == false et aucun site configuré,
// on propose d'ouvrir le tutoriel automatiquement.
(async () => {
  try {
    const settings = await MangaBridgeStorage.getSettings();
    const profiles = await MangaBridgeStorage.getProfiles();
    const hasSites = Object.keys(profiles).length > 0;

    if (settings.tutorialShown && !settings.tutorialVisible) {
      // Tutoriel déjà vu et non réaffiché → cacher l'onglet
      hideTutorialTab();
    } else if (!settings.tutorialShown && !hasSites) {
      // Première utilisation → basculer sur le tutoriel
      setTimeout(() => {
        const tutorialTab = document.querySelector('[data-tab="tutorial"]');
        if (tutorialTab) tutorialTab.click();
      }, 800);
    }
  } catch (e) {
    console.warn('Erreur détection première utilisation:', e);
  }
})();

// Quand l'onglet tutoriel est activé, s'assurer que la barre de progression est correcte
const tutorialObserver = new MutationObserver(() => {
  const tutorialPanel = document.getElementById('mb-tab-tutorial');
  if (tutorialPanel && tutorialPanel.classList.contains('active')) {
    const pct = (tutorialCurrentStep / (TUTORIAL_TOTAL_STEPS - 1)) * 100;
    updateProgressBar(pct);
  }
});
tutorialObserver.observe(document.body, {
  attributes: true,
  attributeFilter: ['class'],
  subtree: true
});
