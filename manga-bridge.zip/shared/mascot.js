// ==========================================
// MangaBridgeMascot — mascotte chibi/robot en SVG inline + bulle de dialogue
// ==========================================
// Pas d'image externe : tout est en SVG vectoriel, léger et redimensionnable
// sans perte, et cohérent avec la palette accent (#f16522) partout dans
// l'extension (popup, options, mode apprentissage).

const MangaBridgeMascot = {
  svg(size = 48) {
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        <polygon points="50,6 88,26 88,72 50,96 12,72 12,26" fill="#f16522"/>
        <polygon points="50,20 27,3 39,24" fill="white"/>
        <polygon points="50,20 73,3 61,24" fill="white"/>
        <polygon points="30,42 70,42 65,80 35,80" fill="white"/>
        <rect x="37" y="54" width="10" height="6" fill="#39dc84"/>
        <rect x="53" y="54" width="10" height="6" fill="#39dc84"/>
        <rect x="42" y="68" width="2" height="8" fill="#1f1f27"/>
        <rect x="48.5" y="68" width="2" height="8" fill="#1f1f27"/>
        <rect x="55" y="68" width="2" height="8" fill="#1f1f27"/>
      </svg>
    `;
  },

  /**
   * Affiche (ou met à jour) une bulle de dialogue flottante avec la mascotte,
   * toujours côte à côte (jamais empilées) : la mascotte se place au bord
   * d'écran vers lequel le bloc est ancré, la bulle de texte s'étend vers le
   * centre — donnant l'impression que la mascotte "pointe" vers la bulle.
   * `style` (prioritaire) vient de computeLearnUIStyle/computeStaticBubbleStyle
   * dans site-injector.js ; `position` reste un repli simple par coin si
   * aucun `style` n'est fourni.
   * Renvoie l'élément conteneur pour permettre de le retirer via .remove().
   */
  showBubble(text, { id = 'mb-mascot-bubble', autoHideMs = null, position = 'bottom-right', style = null } = {}) {
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement('div');
      el.id = id;
      el.style.cssText = `
        position: fixed; z-index: 2147483647;
        display: flex; align-items: flex-end; gap: 10px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        pointer-events: none;
      `;
      // DOM = [bulle de texte, mascotte] : avec flex-direction 'row' la
      // mascotte (dernier enfant) se retrouve à droite du bloc, avec
      // 'row-reverse' elle passe en premier, à gauche — cohérence avec
      // #mb-learn-panel qui suit exactement la même convention.
      el.innerHTML = `
        <div class="mb-bubble-text" style="
          pointer-events:auto; max-width:260px; background:#1f1f27; color:white;
          padding:12px 16px; border-radius:14px; font-size:13px; line-height:1.4;
          box-shadow:0 6px 20px rgba(0,0,0,0.35); border:2px solid #f16522;
        "></div>
        <div style="flex-shrink:0; filter:drop-shadow(0 4px 10px rgba(0,0,0,0.3));">${this.svg(52)}</div>
      `;
      document.body.appendChild(el);
    }

    if (style) {
      el.style.position = style.position || 'fixed';
      el.style.top = style.top ?? 'auto';
      el.style.bottom = style.bottom ?? 'auto';
      el.style.left = style.left ?? 'auto';
      el.style.right = style.right ?? 'auto';
      el.style.flexDirection = style.flexDirection || 'row-reverse';
    } else {
      el.style.position = 'fixed';
      const [vert, horiz] = position.split('-');
      el.style.top = vert === 'top' ? '24px' : 'auto';
      el.style.bottom = vert === 'bottom' ? '24px' : 'auto';
      el.style.left = horiz === 'left' ? '24px' : 'auto';
      el.style.right = horiz === 'right' ? '24px' : 'auto';
      el.style.flexDirection = (horiz === 'left') ? 'row-reverse' : 'row';
    }

    el.querySelector('.mb-bubble-text').innerText = text;
    if (autoHideMs) {
      clearTimeout(el._mbHideTimer);
      el._mbHideTimer = setTimeout(() => el.remove(), autoHideMs);
    }
    return el;
  },

  hideBubble(id = 'mb-mascot-bubble') {
    const el = document.getElementById(id);
    if (el) el.remove();
  }
};

if (typeof window !== 'undefined') {
  window.MangaBridgeMascot = MangaBridgeMascot;
}
