// ==========================================
// MangaBridgeStorage — couche d'accès à chrome.storage.local
// ==========================================
// Contrairement à localStorage (isolé par origine), chrome.storage.local est
// PARTAGÉ par toute l'extension, quel que soit le domaine où s'exécute le
// script qui le lit/l'écrit. C'est ce qui permet à mangacollec-bridge.js
// (qui tourne sur mangacollec.com) d'écrire la collection, et à
// site-injector.js (qui tourne sur n'importe quel site marchand) de la lire
// directement, sans pont GM_setValue/GM_getValue ni ouverture d'onglet
// coordonnée par polling.

const MB_KEYS = {
  DB: 'mangaBridgeDB',
  DB_UPDATED_AT: 'mangaBridgeDBUpdatedAt',
  PROFILES: 'siteProfiles',
  SETTINGS: 'settings',
  LEARNED_PUBLISHERS: 'learnedPublishers',
  LEARNED_GENRES: 'learnedGenres',
  SERIES_KINDS_MAP: 'seriesKindsMap',
  CUSTOM_NOISE_WORDS: 'customNoiseWords',
  CONFIRMED_PREFIX: 'mb_confirmed_',
  ALIAS_PREFIX: 'mb_aliases_',
  SYNC_STATE: 'syncState', // { status: 'idle'|'pending'|'done'|'error', tabId, startedAt }
  PUBLISHER_SYNC_STATE: 'publisherSyncState',
  KINDS_SYNC_STATE: 'kindsSyncState',
  STATS_DATA: 'statsData',
  HISTORY_ITEMS: 'historyItems',
  UNRESOLVED_GENRE_IDS: 'unresolvedGenreIds',
  ENABLED_SITES: 'enabledSites',
  EXCLUDED_PAIRS_PREFIX: 'mb_excluded_pairs_',
  ANNEX_DB: 'annexDB',
  ANNEX_DB_UPDATED_AT: 'annexDBUpdatedAt'
};

const DEFAULT_SETTINGS = {
  hideOwned: false,
  mangacollecUsername: '',
  panelPosition: 'bottom-right', // 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
  bubbleMode: 'follow', // 'follow' (à côté de la zone sélectionnée) | 'bottom-right' | 'bottom-left'
  tutorialShown: false, // true après que l'utilisateur a parcouru le tutoriel
  tutorialVisible: false // true si l'utilisateur a demandé de revoir le tutoriel après l'avoir terminé
};

const MangaBridgeStorage = {
  async getDB() {
    const r = await chrome.storage.local.get(MB_KEYS.DB);
    return r[MB_KEYS.DB] || {};
  },
  async setDB(db) {
    return chrome.storage.local.set({
      [MB_KEYS.DB]: db,
      [MB_KEYS.DB_UPDATED_AT]: Date.now()
    });
  },
  async getDBUpdatedAt() {
    const r = await chrome.storage.local.get(MB_KEYS.DB_UPDATED_AT);
    return r[MB_KEYS.DB_UPDATED_AT] || null;
  },

  async getProfiles() {
    const r = await chrome.storage.local.get(MB_KEYS.PROFILES);
    return r[MB_KEYS.PROFILES] || {};
  },
  async getProfile(hostname) {
    const profiles = await this.getProfiles();
    return profiles[hostname] || null;
  },
  // Renvoie toujours un tableau de jeux {cardSelector, titleSelector, label},
  // même pour les anciens profils qui n'avaient qu'un seul jeu à plat
  // (cardSelector/titleSelector directement sur le profil).
  async getSelectorSets(hostname) {
    const profile = await this.getProfile(hostname);
    if (!profile) return [];
    if (Array.isArray(profile.selectors)) return profile.selectors;
    if (profile.cardSelector) return [{ cardSelector: profile.cardSelector, titleSelector: profile.titleSelector, label: 'Principal' }];
    return [];
  },
  async addSelectorSet(hostname, set) {
    const sets = await this.getSelectorSets(hostname);
    sets.push(set);
    return chrome.storage.local.set({
      [MB_KEYS.PROFILES]: { ...(await this.getProfiles()), [hostname]: { selectors: sets, createdAt: Date.now() } }
    });
  },
  async removeSelectorSet(hostname, index) {
    const sets = await this.getSelectorSets(hostname);
    sets.splice(index, 1);
    const profiles = await this.getProfiles();
    if (sets.length === 0) {
      delete profiles[hostname];
    } else {
      profiles[hostname] = { selectors: sets, createdAt: Date.now() };
    }
    return chrome.storage.local.set({ [MB_KEYS.PROFILES]: profiles });
  },
  async updateSelectorSet(hostname, index, patch) {
    const sets = await this.getSelectorSets(hostname);
    if (!sets[index]) return;
    sets[index] = { ...sets[index], ...patch };
    const profiles = await this.getProfiles();
    profiles[hostname] = { selectors: sets, createdAt: Date.now() };
    return chrome.storage.local.set({ [MB_KEYS.PROFILES]: profiles });
  },
  async setProfile(hostname, profile) {
    const profiles = await this.getProfiles();
    profiles[hostname] = profile;
    return chrome.storage.local.set({ [MB_KEYS.PROFILES]: profiles });
  },
  async deleteProfile(hostname) {
    const profiles = await this.getProfiles();
    delete profiles[hostname];
    return chrome.storage.local.set({ [MB_KEYS.PROFILES]: profiles });
  },

  async getSettings() {
    const r = await chrome.storage.local.get(MB_KEYS.SETTINGS);
    return { ...DEFAULT_SETTINGS, ...(r[MB_KEYS.SETTINGS] || {}) };
  },
  async setSettings(patch) {
    const current = await this.getSettings();
    const merged = { ...current, ...patch };
    return chrome.storage.local.set({ [MB_KEYS.SETTINGS]: merged });
  },

  async getLearnedPublishers() {
    const r = await chrome.storage.local.get(MB_KEYS.LEARNED_PUBLISHERS);
    return r[MB_KEYS.LEARNED_PUBLISHERS] || {};
  },
  async setLearnedPublishers(obj) {
    return chrome.storage.local.set({ [MB_KEYS.LEARNED_PUBLISHERS]: obj });
  },

  // Les genres ("kinds") sont récupérés dynamiquement depuis l'API
  // Mangacollec (/v2/kinds) lors de la synchro, stockés ici sous forme de
  // mapping id -> nom pour usage local (matching, suggestions, base annexes).
  async getLearnedGenres() {
    const r = await chrome.storage.local.get(MB_KEYS.LEARNED_GENRES);
    return r[MB_KEYS.LEARNED_GENRES] || {};
  },
  async setLearnedGenres(obj) {
    return chrome.storage.local.set({ [MB_KEYS.LEARNED_GENRES]: obj });
  },

  // Mots ajoutés manuellement (onglet Matching des options) à retirer des
  // titres avant comparaison, en plus du bruit déjà géré par défaut
  // (collector, tome/vol/volume, noms de genre...). Liste globale, partagée
  // par tous les sites — un mot parasite (ex: le nom d'un label collection)
  // n'a pas de raison d'être spécifique à un site.
  async getCustomNoiseWords() {
    const r = await chrome.storage.local.get(MB_KEYS.CUSTOM_NOISE_WORDS);
    return r[MB_KEYS.CUSTOM_NOISE_WORDS] || [];
  },
  async setCustomNoiseWords(list) {
    return chrome.storage.local.set({ [MB_KEYS.CUSTOM_NOISE_WORDS]: list });
  },

  // seriesId -> [kind_id, ...] dans l'ordre renvoyé par l'API collection.
  // Permet, sur une page /series/:id, d'associer chaque badge de genre
  // affiché (dans le même ordre) à son ID — capture passive en arrière-plan
  // pendant la navigation normale de l'utilisateur, sans ouvrir/fermer
  // d'onglet ni interférer avec quoi que ce soit.
  async getSeriesKindsMap() {
    const r = await chrome.storage.local.get(MB_KEYS.SERIES_KINDS_MAP);
    return r[MB_KEYS.SERIES_KINDS_MAP] || {};
  },
  async setSeriesKindsMap(obj) {
    return chrome.storage.local.set({ [MB_KEYS.SERIES_KINDS_MAP]: obj });
  },

  async getConfirmed(hostname) {
    const key = MB_KEYS.CONFIRMED_PREFIX + hostname;
    const r = await chrome.storage.local.get(key);
    return r[key] || {};
  },
  async setConfirmed(hostname, obj) {
    const key = MB_KEYS.CONFIRMED_PREFIX + hostname;
    return chrome.storage.local.set({ [key]: obj });
  },

  async getAliases(hostname) {
    const key = MB_KEYS.ALIAS_PREFIX + hostname;
    const r = await chrome.storage.local.get(key);
    return r[key] || {};
  },
  async setAliases(hostname, obj) {
    const key = MB_KEYS.ALIAS_PREFIX + hostname;
    return chrome.storage.local.set({ [key]: obj });
  },

  async getSyncState() {
    const r = await chrome.storage.local.get(MB_KEYS.SYNC_STATE);
    return r[MB_KEYS.SYNC_STATE] || { status: 'idle' };
  },
  async setSyncState(state) {
    return chrome.storage.local.set({ [MB_KEYS.SYNC_STATE]: state });
  },

  async getPublisherSyncState() {
    const r = await chrome.storage.local.get(MB_KEYS.PUBLISHER_SYNC_STATE);
    return r[MB_KEYS.PUBLISHER_SYNC_STATE] || { status: 'idle' };
  },
  async setPublisherSyncState(state) {
    return chrome.storage.local.set({ [MB_KEYS.PUBLISHER_SYNC_STATE]: state });
  },

  async getKindsSyncState() {
    const r = await chrome.storage.local.get(MB_KEYS.KINDS_SYNC_STATE);
    return r[MB_KEYS.KINDS_SYNC_STATE] || { status: 'idle' };
  },
  async setKindsSyncState(state) {
    return chrome.storage.local.set({ [MB_KEYS.KINDS_SYNC_STATE]: state });
  },

  async getStatsData() {
    const r = await chrome.storage.local.get(MB_KEYS.STATS_DATA);
    return r[MB_KEYS.STATS_DATA] || { publishers: {}, genres: {} };
  },
  async setStatsData(data) {
    return chrome.storage.local.set({ [MB_KEYS.STATS_DATA]: data });
  },
  async getHistoryItems() {
    const r = await chrome.storage.local.get(MB_KEYS.HISTORY_ITEMS);
    return r[MB_KEYS.HISTORY_ITEMS] || [];
  },
  async setHistoryItems(items) {
    return chrome.storage.local.set({ [MB_KEYS.HISTORY_ITEMS]: items });
  },
  async getUnresolvedGenreIds() {
    const r = await chrome.storage.local.get(MB_KEYS.UNRESOLVED_GENRE_IDS);
    return r[MB_KEYS.UNRESOLVED_GENRE_IDS] || [];
  },
  async setUnresolvedGenreIds(ids) {
    return chrome.storage.local.set({ [MB_KEYS.UNRESOLVED_GENRE_IDS]: ids });
  },

  // Un site n'affiche RIEN (ni panneau, ni badges) tant que l'utilisateur ne
  // l'a pas explicitement activé depuis le popup — évite de polluer chaque
  // site visité avec un bouton flottant non désiré.
  async getEnabledSites() {
    const r = await chrome.storage.local.get(MB_KEYS.ENABLED_SITES);
    return r[MB_KEYS.ENABLED_SITES] || {};
  },
  async isSiteEnabled(hostname) {
    const sites = await this.getEnabledSites();
    return !!sites[hostname];
  },
  async setSiteEnabled(hostname, enabled) {
    const sites = await this.getEnabledSites();
    if (enabled) sites[hostname] = true;
    else delete sites[hostname];
    return chrome.storage.local.set({ [MB_KEYS.ENABLED_SITES]: sites });
  },

  // Exclusion d'un COUPLE précis [titre vu sur le site + entrée BDD résolue
  // par le matching AUTOMATIQUE], scopée au site en cours. Contrairement à
  // un blocage par clé de série (qui empêchait TOUTE occurrence de cette
  // série d'être matchée sur ce site, même via un autre titre légitime),
  // seule CETTE association précise est désactivée — un autre titre de site
  // qui matcherait naturellement la même entrée BDD n'est pas affecté, et le
  // matching manuel (alias) reste totalement indépendant de cette liste.
  pairKey(cleanGeneric, dbKey) {
    return `${cleanGeneric}::${dbKey}`;
  },
  async getExcludedPairs(hostname) {
    const key = MB_KEYS.EXCLUDED_PAIRS_PREFIX + hostname;
    const r = await chrome.storage.local.get(key);
    return r[key] || {};
  },
  async setExcludedPairs(hostname, obj) {
    const key = MB_KEYS.EXCLUDED_PAIRS_PREFIX + hostname;
    return chrome.storage.local.set({ [key]: obj });
  },
  async excludePair(hostname, cleanGeneric, dbKey, siteTitle, dbNom) {
    const excluded = await this.getExcludedPairs(hostname);
    excluded[this.pairKey(cleanGeneric, dbKey)] = { cleanGeneric, dbKey, siteTitle, dbNom, at: Date.now() };
    return this.setExcludedPairs(hostname, excluded);
  },
  async unexcludePair(hostname, pairKey) {
    const excluded = await this.getExcludedPairs(hostname);
    delete excluded[pairKey];
    return this.setExcludedPairs(hostname, excluded);
  },
  // Pour la page d'options : liste tous les sites ayant au moins un couple
  // exclu, en parcourant les clés de stockage existantes.
  async getAllExcludedByHost() {
    const all = await chrome.storage.local.get(null);
    const result = {};
    Object.keys(all).forEach(k => {
      if (k.startsWith(MB_KEYS.EXCLUDED_PAIRS_PREFIX)) {
        const hostname = k.slice(MB_KEYS.EXCLUDED_PAIRS_PREFIX.length);
        if (Object.keys(all[k] || {}).length > 0) result[hostname] = all[k];
      }
    });
    return result;
  },

  // ⚠️ Intentionnellement un no-op : ne PAS tronquer le hash (#...) ni la query
  // string (?...) : sur de nombreux sites (panda-manga.fr, bazardumanga.com...)
  // c'est justement là que vit l'identifiant unique de l'article (#4342,
  // ?id_manga=273...). Les supprimer faisait retomber toutes les cartes d'une
  // même page sur exactement la même URL "nettoyée" — un seul "Ignorer"/alias
  // par URL s'appliquait alors silencieusement à des dizaines d'articles
  // différents.
  cleanUrl(url) {
    return url;
  },

  // ==========================================
  // Base annexes — mangas absents de Mangacollec
  // ==========================================
  // Structure : { clé: { nom, edition, publisher, tomes: ["1","2"], ratio: "2/5", genres: ["Shonen"] }, ... }
  async getAnnexDB() {
    const r = await chrome.storage.local.get(MB_KEYS.ANNEX_DB);
    return r[MB_KEYS.ANNEX_DB] || {};
  },
  async setAnnexDB(db) {
    return chrome.storage.local.set({
      [MB_KEYS.ANNEX_DB]: db,
      [MB_KEYS.ANNEX_DB_UPDATED_AT]: Date.now()
    });
  },
  async getAnnexDBUpdatedAt() {
    const r = await chrome.storage.local.get(MB_KEYS.ANNEX_DB_UPDATED_AT);
    return r[MB_KEYS.ANNEX_DB_UPDATED_AT] || null;
  },
  async addAnnexEntry(entry) {
    const db = await this.getAnnexDB();
    const key = window.MangaBridgeMatcher?.TextProcessor?.noiseClean(entry.nom) || entry.nom;
    db[key] = entry;
    return this.setAnnexDB(db);
  },
  async updateAnnexEntry(key, patch) {
    const db = await this.getAnnexDB();
    if (!db[key]) return;
    db[key] = { ...db[key], ...patch };
    return this.setAnnexDB(db);
  },
  async deleteAnnexEntry(key) {
    const db = await this.getAnnexDB();
    delete db[key];
    return this.setAnnexDB(db);
  },

  // ==========================================
  // Export / Import complet de l'état de l'extension
  // ==========================================
  // Récupère TOUTES les clés de chrome.storage.local et renvoie un objet
  // sérialisable en JSON — l'utilisateur peut sauvegarder ce JSON et le
  // réinjecter plus tard (ou sur un autre appareil) pour restaurer l'état.
  async exportFullState() {
    const all = await chrome.storage.local.get(null);
    // Marqueur pour identifier le fichier comme un backup Manga-Bridge
    return { ...(all || {}), _mangaBridgeBackup: true };
  },
  async importFullState(data) {
    if (!data || typeof data !== 'object') return false;
    // Vérifie que le fichier vient bien de Manga-Bridge
    if (data._mangaBridgeBackup !== true) return false;
    await chrome.storage.local.clear();
    // On retire le marqueur avant de réinjecter pour ne pas polluer le storage
    delete data._mangaBridgeBackup;
    await chrome.storage.local.set(data);
    return true;
  },

  // ==========================================
  // Export / Import Light
  // ==========================================
  // Sauvegarde uniquement les données utilisateur (pas Mangacollec) :
  // base annexes, profils de sites, paramètres, mots ignorés, matchs exclus.
  // Exclut : base de correspondance, historique, stats, état de synchro,
  // genres/éditeurs appris (récupérés automatiquement via synchro Mangacollec).
  async exportLightState() {
    const all = await chrome.storage.local.get(null);
    if (!all) return {};
    // Clés liées à Mangacollec à exclure
    const excludeKeys = [
      MB_KEYS.DB,
      MB_KEYS.DB_UPDATED_AT,
      MB_KEYS.HISTORY_ITEMS,
      MB_KEYS.SYNC_STATE,
      MB_KEYS.PUBLISHER_SYNC_STATE,
      MB_KEYS.STATS_DATA,
      MB_KEYS.LEARNED_PUBLISHERS,
      MB_KEYS.LEARNED_GENRES
    ];
    const light = {};
    for (const key of Object.keys(all)) {
      if (!excludeKeys.includes(key)) {
        light[key] = all[key];
      }
    }
    // Marqueur pour identifier le fichier comme un backup Manga-Bridge
    light._mangaBridgeBackup = true;
    return light;
  },
  async importLightState(data) {
    if (!data || typeof data !== 'object') return false;
    // Vérifie que le fichier vient bien de Manga-Bridge
    if (data._mangaBridgeBackup !== true) return false;
    // On retire le marqueur avant de fusionner pour ne pas polluer le storage
    delete data._mangaBridgeBackup;
    // Fusionner avec les données existantes sans écraser Mangacollec
    await chrome.storage.local.set(data);
    return true;
  }
};

// Exposé globalement pour les autres scripts de contenu chargés ensuite
// dans le même monde isolé (voir l'ordre des fichiers dans manifest.json).
if (typeof window !== 'undefined') {
  window.MangaBridgeStorage = MangaBridgeStorage;
  window.MB_KEYS = MB_KEYS;
}
