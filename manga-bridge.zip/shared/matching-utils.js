// ==========================================
// MangaBridge — Utilitaires de matching partagés
// ==========================================
// Fonctions utilisées à la fois par le service worker (background.js) et par
// les content scripts (content/matcher.js).  Exportées sur l'objet global
// pour qu'elles soient accessibles dans les deux contextes.

if (typeof MB_AUTO_MATCH_THRESHOLD === 'undefined') {
  const MB_AUTO_MATCH_THRESHOLD = 0.80;
  if (typeof window !== 'undefined') window.MB_AUTO_MATCH_THRESHOLD = MB_AUTO_MATCH_THRESHOLD;
  if (typeof globalThis !== 'undefined') globalThis.MB_AUTO_MATCH_THRESHOLD = MB_AUTO_MATCH_THRESHOLD;
}

if (typeof MB_STOPWORDS === 'undefined') {
  const MB_STOPWORDS = new Set([
    'le', 'la', 'les', 'de', 'du', 'des', 'un', 'une', 'en', 'et', 'au', 'aux',
    'the', 'a', 'an', 'in', 'of'
  ]);
  if (typeof window !== 'undefined') window.MB_STOPWORDS = MB_STOPWORDS;
  if (typeof globalThis !== 'undefined') globalThis.MB_STOPWORDS = MB_STOPWORDS;
}

// ---- MBTextProcessor -------------------------------------------------
const MBTextProcessor = {
  runtimeCache: new Map(),
  runtimeCacheMax: 5000, // LRU : borner la mémoire
  customNoiseWords: [],

  setCustomNoiseWords(list) {
    this.customNoiseWords = Array.isArray(list) ? list : [];
    this.runtimeCache.clear();
  },

  // Cache LRU : évite la fuite mémoire sur sessions longues
  _safeRegex(input) {
    // Protège contre ReDoS : limiter la longueur, échapper les chars spéciaux,
    // et envelopper dans un try/catch au cas où.
    if (!input || typeof input !== 'string') return null;
    const sanitized = input.slice(0, 100).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    try {
      return new RegExp(`\\b${sanitized}\\b`, 'gi');
    } catch (_) {
      return null; // regex invalide → on ignore le mot
    }
  },

  _cachePut(key, value) {
    const c = this.runtimeCache;
    if (c.has(key)) {
      c.set(key, value);
    } else if (c.size < this.runtimeCacheMax) {
      c.set(key, value);
    } else {
      // Map itère dans l'ordre d'insertion → la première entrée est la + vieille
      c.delete(c.keys().next().value);
      c.set(key, value);
    }
  },

  ultraClean(str) {
    if (!str) return "";
    return str.toLowerCase()
      .replace(/œ/g, 'oe')
      .replace(/æ/g, 'ae')
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
  },

  getSortedTokens(cleanedStr) {
    if (!cleanedStr) return "";
    const stopwords = (typeof MB_STOPWORDS !== 'undefined') ? MB_STOPWORDS : new Set();
    return cleanedStr.split(/[\s'\'–—.,:_/\\\(\)\[\]-]+/)
      .filter(token => token.length > 0 && !stopwords.has(token))
      .sort()
      .join(' ');
  },

  // Version complète (content script) : retrait des genres, customNoiseWords, bruit éditorial
  noiseClean(str, options = {}) {
    if (!str) return "";
    if (this.runtimeCache.has(str)) return this.runtimeCache.get(str);

    let s = this.ultraClean(str);



    // Crochets → infos éditoriales
    s = s.replace(/\[.*?\]/g, ' ');

    // Parenthèses : supprimées de manière générique (occasion, édition, contenu, etc.)
    s = s.replace(/\([^)]*\)/g, ' ');

    // Genres (si fournis) — regex protégée contre ReDoS
    // Ne pas supprimer un genre si :
    // - il apparaît plus d'une fois (ex: "Otaku Otaku" → c'est le titre, pas un genre)
    // - il constitue > 50% des mots (sinon on vide le titre)
    // - après suppression, il reste moins de 2 mots significatifs
    if (options.genres) {
      const wordCount = s.split(/\s+/).filter(t => t.length > 0).length;
      options.genres.forEach(genre => {
        if (genre && genre.length > 2) {
          const genreRegex = this._safeRegex(genre);
          if (genreRegex) {
            const matches = s.match(genreRegex);
            if (!matches) return;
            if (matches.length > 1) return; // mot répété → probablement le titre
            if (matches.length > wordCount * 0.5) return; // trop de mots supprimés
            const testResult = s.replace(genreRegex, ' ').trim();
            const remainingWords = testResult.split(/\s+/).filter(t => t.length > 0);
            if (remainingWords.length < 2) return; // trop peu de mots restants
            s = testResult;
          }
        }
      });
    }

    // Mots ignorés personnalisés — regex protégée contre ReDoS
    this.customNoiseWords.forEach(word => {
      if (word && word.length > 1) {
        const wordRegex = this._safeRegex(word);
        if (wordRegex) s = s.replace(wordRegex, ' ');
      }
    });

    // Bruit éditorial standard
    const noises = [
      /\s*-\s*é?edition\s+[a-z0-9]+/gi,
      /\b(collector|deluxe|perfect|ultimate|double|integrale|speciale?|anthologie|anthology)\b/gi,
      /\ben\s+cours\b/gi,
      /\b(nouvelle\s+é?edition|nouvelle\s+editions?)\b/gi,
      /\s*-\s*ancienne édition.*$/i,
      // "édition" seul (en fin de chaîne ou isolé) est du bruit éditorial
      /\b(edition|édition)\b/gi,
      /\stome\s*\.?\s*\d+/gi, /\svol\.?\s*\d+/gi, /\svolume\s*\.?\s*\d+/gi,
      /\bt\d{1,3}\b/gi, // tome abrégé : t02, t10, t123
      /\blivre\b/gi, /\bmanga\b/gi, /\bposter\b/gi,
      // Prix : "4.90€", "4,90€", "€4.90", "10 EUR", etc.
      /\d+[.,]?\d*\s*€/gi, /€\s*\d+[.,]?\d*/gi, /\d+\s*(?:eur|euros?)/gi,
    ];
    noises.forEach(reg => { s = s.replace(reg, ' '); });
    s = s.replace(/\s+/g, ' ').trim();

    // Supprimer TOUS les numéros trainants en fin de chaîne (sauf "saison" / "partie")
    // Boucle nécessaire car "1 + 2" nettoyé → "1 2" → plusieurs chiffres isolés
    // Limite d'itérations pour éviter une boucle infinie en cas de regex pathologique
    let prev;
    let iterations = 0;
    const maxIterations = 50;
    do {
      prev = s;
      const m = s.match(/(.*)\s(\d+)$/);
      if (m) {
        const tb = m[1].trim();
        if (!tb.toLowerCase().endsWith('saison') && !tb.toLowerCase().endsWith('partie') && tb.length > 3)
          s = tb;
      } else break;
    } while (s !== prev && ++iterations < maxIterations);

    // Nettoyage final : tirets et ponctuation trainante (ex: "titre -" après suppression "vol 3")
    s = s.replace(/[\s-]+$/, '').trim();

    const result = s.trim();
    this._cachePut(str, result);
    return result;
  },

  // Version simplifiée (background.js) : sans genres ni customNoiseWords
  noiseCleanSimple(str) {
    if (!str) return "";
    if (this.runtimeCache.has(str)) return this.runtimeCache.get(str);

    let s = this.ultraClean(str);
    s = s.replace(/\[.*?\]/g, ' ');

    // Parenthèses ciblées (condition uniquement)
    s = s.replace(/\(numéro blanc\)/gi, ' ');
    s = s.replace(/\(occasion\)/gi, ' ');
    s = s.replace(/\(neuf\)/gi, ' ');

    // Parenthèses éditoriales : (édition ...), (version ...), etc.
    s = s.replace(/\(é?edition[^)]*\)/gi, ' ');
    s = s.replace(/\(version[^)]*\)/gi, ' ');

    const noises = [
      /\s*-\s*é?edition\s+[a-z0-9]+/gi,
      /\b(collector|deluxe|perfect|ultimate|double|integrale|speciale?|anthologie|anthology)\b/gi,
      /\ben\s+cours\b/gi,
      /\b(nouvelle\s+é?edition|nouvelle\s+editions?)\b/gi,
      /\s*-\s*ancienne édition.*$/i,
      /\stome\s*\.?\s*\d+/gi, /\svol\.?\s*\d+/gi, /\svolume\s*\.?\s*\d+/gi,
      /\bt\d{1,3}\b/gi, // tome abrégé : t02, t10, t123 (manquait dans noiseCleanSimple)
      /\blivre\b/gi, /\bmanga\b/gi, /\bposter\b/gi,
      // Prix : "4.90€", "4,90€", "€4.90", "10 EUR", etc.
      /\d+[.,]?\d*\s*€/gi, /€\s*\d+[.,]?\d*/gi, /\d+\s*(?:eur|euros?)/gi,
    ];
    noises.forEach(reg => { s = s.replace(reg, ' '); });
    s = s.replace(/\s+/g, ' ').trim();

    // Supprimer TOUS les numéros trainants (même version, cohérent avec noiseClean)
    // Limite d'itérations pour éviter une boucle infinie en cas de regex pathologique
    let prev;
    let iterations = 0;
    const maxIterations = 50;
    do {
      prev = s;
      const m = s.match(/(.*)\s(\d+)$/);
      if (m) {
        const tb = m[1].trim();
        if (!tb.toLowerCase().endsWith('saison') && !tb.toLowerCase().endsWith('partie') && tb.length > 3)
          s = tb;
      } else break;
    } while (s !== prev && ++iterations < maxIterations);

    // Nettoyage final : tirets et ponctuation trainante
    s = s.replace(/[\s-]+$/, '').trim();

    const result = s.trim();
    this._cachePut(str, result);
    return result;
  }
};

// ---- MBMatching ------------------------------------------------------
const MBMatching = {
  levenshtein(a, b) {
    const tmp = [];
    for (let i = 0; i <= b.length; i++) tmp[i] = [i];
    for (let j = 0; j <= a.length; j++) tmp[0][j] = j;
    for (let i = 1; i <= b.length; i++) {
      for (let j = 1; j <= a.length; j++) {
        if (b.charAt(i - 1) === a.charAt(j - 1)) tmp[i][j] = tmp[i - 1][j - 1];
        else tmp[i][j] = Math.min(tmp[i - 1][j - 1] + 1, tmp[i][j - 1] + 1, tmp[i - 1][j] + 1);
      }
    }
    return tmp[b.length][a.length];
  },

  // Score entre deux strings brutes (utilisé par background.js)
  calculateScore(str1, str2) {
    const threshold = (typeof MB_AUTO_MATCH_THRESHOLD !== 'undefined') ? MB_AUTO_MATCH_THRESHOLD : 0.80;
    const s1 = MBTextProcessor.noiseCleanSimple(str1);
    const s2 = MBTextProcessor.noiseCleanSimple(str2);
    if (!s1 || !s2) return 0;
    if (s1 === s2) return 1;

    const t1 = MBTextProcessor.getSortedTokens(s1);
    const t2 = MBTextProcessor.getSortedTokens(s2);
    if (t1 && t2 && t1 === t2) return 1;

    return MBMatching._coreScore(s1, s2, threshold);
  },

  // Score entre un titre site et une entry pré-nettoyée (utilisé par matcher.js)
  calculateScoreWithEntry(siteTitle, cleanedName, sortedTokens) {
    const threshold = (typeof MB_AUTO_MATCH_THRESHOLD !== 'undefined') ? MB_AUTO_MATCH_THRESHOLD : 0.80;
    const s1 = MBTextProcessor.noiseClean(siteTitle);
    const s2 = cleanedName;
    if (!s1 || !s2) return 0;
    if (s1 === s2) return 1;

    const t1 = MBTextProcessor.getSortedTokens(s1);
    const t2 = sortedTokens;
    if (t1 && t2 && t1 === t2) return 1;

    return MBMatching._coreScore(s1, s2, threshold);
  },

  // Logique commune de scoring (après nettoyage + token sort)
  _coreScore(s1, s2, threshold) {
    const len1 = s1.length, len2 = s2.length;
    const shorter = len1 < len2 ? s1 : s2;
    const longer = len1 < len2 ? s2 : s1;
    const ratio = shorter.length / longer.length;

    let weight = 1.0;
    if (longer.startsWith(shorter) && ratio >= 0.5) {
      // Préfixe exact : vérifier si le suffixe restant contient des mots
      // significatifs (ex: "dragon ball" vs "dragon ball kame" → "kame" est
      // un suffixe distinctif → pénalité au lieu de bonus).
      const suffix = longer.slice(shorter.length).trim();
      const suffixTokens = suffix.split(/\s+/).filter(t => t.length > 0);
      if (suffixTokens.length === 0) {
        // Pas de suffixe réel (strings quasi identiques) → bonus conservé
        weight = 1.15;
      } else {
        // Suffixe significatif détecté → pénalité proportionnelle
        // Plus le suffixe est important, plus on pénalise.
        const suffixWeight = suffix.length / longer.length;
        weight = Math.max(0.5, 1.0 - suffixWeight);
      }
    } else if (longer.endsWith(shorter) && ratio >= 0.5) {
      weight = 0.85;
    }

    if (shorter.length > 3) {
      // Regex protégée : échapper les chars spéciaux + try/catch + limite longueur
      const safeInput = shorter.slice(0, 200);
      let regex;
      try {
        regex = new RegExp(`\\b${safeInput.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
      } catch (_) {
        regex = null;
      }
      if (regex && regex.test(longer)) {
        const raw1 = s1.toLowerCase();
        const raw2 = s2.toLowerCase();
        const hasPlus1 = raw1.includes('+'), hasPlus2 = raw2.includes('+');
        const hasX1 = /\bx\b/i.test(raw1), hasX2 = /\bx\b/i.test(raw2);
        if (hasPlus1 !== hasPlus2 || hasX1 !== hasX2) return 0;
        const baseScore = (ratio < 0.6) ? 0.7 : 0.95;
        return Math.min(1, baseScore * weight);
      }
    }

    const maxLen = Math.max(len1, len2);
    const minPossibleDistance = Math.abs(len1 - len2);
    if ((maxLen - minPossibleDistance) / maxLen < threshold - 0.15) return 0;

    const dist = MBMatching.levenshtein(s1, s2);
    const score = (maxLen - dist) / maxLen;
    const finalScore = (ratio < 0.5) ? score * 0.8 : score;
    return Math.min(1, finalScore * weight);
  }
};

// Export global pour les content scripts
if (typeof window !== 'undefined') {
  window.MBTextProcessor = MBTextProcessor;
  window.MBMatching = MBMatching;
}
